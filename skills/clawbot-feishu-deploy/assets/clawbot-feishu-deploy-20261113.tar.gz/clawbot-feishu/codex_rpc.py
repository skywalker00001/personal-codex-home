"""Version-matched Codex app-server JSONL client; owns only its child process."""
from __future__ import annotations

import json
import os
import queue
import subprocess
import threading

from codex_runtime import resolve_binary


class RPCError(RuntimeError):
    pass


class CodexRPC:
    def __init__(self, home, cwd, callback=None, binary="codex"):
        self.callback = callback or (lambda message: None)
        self.lock = threading.RLock()
        self.waiters = {}
        self.counter = 0
        self.closing = False
        env = dict(os.environ, CODEX_HOME=str(home))
        # A child is a distinct Codex session, not the parent agent's current turn.
        for key in list(env):
            if key in {"CODEX_THREAD_ID", "CODEX_TURN_ID", "CODEX_INTERNAL_ORIGINATOR_OVERRIDE"}:
                env.pop(key)
        self.proc = subprocess.Popen([resolve_binary(binary), "app-server"], cwd=str(cwd), env=env,
                                     stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                     stderr=subprocess.DEVNULL, text=True, bufsize=1)
        self.reader = threading.Thread(target=self._read, daemon=True)
        self.reader.start()
        try:
            self.call("initialize", {"clientInfo": {"name": "houyi_wechat", "version": "1.0.0"},
                                     "capabilities": {"experimentalApi": True}})
            self.send({"method": "initialized", "params": {}})
        except Exception:
            self.close()
            raise

    def send(self, message):
        with self.lock:
            if self.proc.poll() is not None:
                raise RPCError("Codex 进程已退出")
            self.proc.stdin.write(json.dumps(message, ensure_ascii=False) + "\n")
            self.proc.stdin.flush()

    def call(self, method, params, timeout=45):
        with self.lock:
            self.counter += 1
            ident = self.counter
            waiter = queue.Queue(maxsize=1)
            self.waiters[ident] = waiter
        try:
            self.send({"id": ident, "method": method, "params": params})
            try:
                message = waiter.get(timeout=timeout)
            except queue.Empty as exc:
                raise RPCError(f"{method} 超时；执行状态需核对，未自动重试") from exc
            if "error" in message:
                raise RPCError(str(message["error"].get("message", message["error"])))
            return message.get("result", {})
        finally:
            with self.lock:
                self.waiters.pop(ident, None)

    def _read(self):
        try:
            for line in self.proc.stdout:
                try:
                    message = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if "id" in message and "method" not in message:
                    with self.lock:
                        waiter = self.waiters.get(message["id"])
                    if waiter:
                        try:
                            waiter.put_nowait(message)
                        except queue.Full:
                            pass
                else:
                    self.callback(message)
        finally:
            with self.lock:
                for waiter in self.waiters.values():
                    try:
                        waiter.put_nowait({"error": {"message": "Codex 连接已断开"}})
                    except queue.Full:
                        pass
            if not self.closing:
                self.callback({"method": "bridge/disconnected", "params": {}})

    def close(self):
        self.closing = True
        if self.proc.poll() is None:
            try:
                self.proc.stdin.close()
                self.proc.wait(timeout=5)
            except (subprocess.TimeoutExpired, BrokenPipeError):
                self.proc.terminate()
                try:
                    self.proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    self.proc.kill()
                    self.proc.wait(timeout=3)
        if threading.current_thread() is not self.reader:
            self.reader.join(timeout=2)

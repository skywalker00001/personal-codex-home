import io
import json
import os
import threading
import time
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock

import pytest
from PIL import Image

from feishu_media import FeishuMedia, MediaError, incoming_content, MAX_AUDIO_BYTES
from voice_understanding import VoiceError
from test_feishu import bridge, settings_bridge, SettingsRPC, FIRST, bind, message


def media_event(kind, content, **kwargs):
    value = message('', **kwargs)
    value['event']['message'].update(message_type=kind, content=json.dumps(content))
    return value


def picture():
    result = io.BytesIO()
    Image.new('RGB', (64, 48), 'red').save(result, format='JPEG')
    return result.getvalue()


def client_with(raw=b'', code=0, msg=''):
    response = SimpleNamespace(success=lambda: code == 0, code=code, msg=msg, file=io.BytesIO(raw))
    get = Mock(return_value=response)
    return SimpleNamespace(im=SimpleNamespace(v1=SimpleNamespace(message_resource=SimpleNamespace(get=get)))), get


@pytest.mark.parametrize('kind,content', [('image', {'image_key': 'img_test'}), ('audio', {'file_key': 'file_test'})])
def test_media_requires_bound_owner_and_exact_private_chat(bridge, kind, content):
    assert not bridge.on_message(media_event(kind, content))
    bind(bridge)
    assert not bridge.on_message(media_event(kind, content, owner='ou_other', ident='other'))
    assert not bridge.on_message(media_event(kind, content, chat_type='group', ident='group'))
    assert not bridge.on_message(media_event(kind, content, chat='oc_other', ident='other_chat'))
    assert bridge.on_message(media_event(kind, content, ident='media'))
    assert bridge.on_message(media_event(kind, content, ident='media'))
    row = bridge.store.claim()
    assert json.loads(row['body'])['feishu_media'][0]['kind'] == kind
    assert bridge.store.claim() is None


@pytest.mark.parametrize('key', ['../../private', '/etc/passwd', 'https://evil.test/image', '', None, 'x' * 301])
def test_message_never_accepts_attachment_urls_or_paths(bridge, key):
    bind(bridge)
    assert not bridge.on_message(media_event('image', {'image_key': key}))


def test_rich_post_keeps_caption_and_images():
    text, images = incoming_content('post', {'zh_cn': {'title': '看这张图', 'content': [
        [{'tag': 'text', 'text': '图里的数字是什么？'}, {'tag': 'img', 'image_key': 'img_1'}],
        [{'tag': 'img', 'image_key': 'img_1'}, {'tag': 'img', 'image_key': 'img_2'}]]}})
    assert text == '看这张图\n图里的数字是什么？'
    assert [x['key'] for x in images] == ['img_1', 'img_2']
    with pytest.raises(ValueError):
        incoming_content('post', {'content': [[{'tag': 'media', 'file_key': 'not_supported'}]]})
    with pytest.raises(ValueError):
        incoming_content('post', {'content': [[{'tag': 'img', 'image_key': 'img_' + str(i)} for i in range(9)]]})


def test_websocket_only_queues_media_and_worker_understands_it(bridge):
    bind(bridge)
    handler = Mock()
    handler.prepare.return_value = ('【飞书语音原音理解】请回复七十三', [], 'feishu-direct-audio')
    bridge.media_handler = handler
    bridge.engine.dispatch = Mock(return_value='语音回复完成')
    assert bridge.on_message(media_event('audio', {'file_key': 'file_1'}, ident='audio_1'))
    handler.prepare.assert_not_called()
    assert bridge.process_one()
    assert '七十三' in bridge.engine.dispatch.call_args.args[0]
    assert bridge.store.get('last_voice')['source'] == 'feishu-direct-audio'
    assert not bridge.process_one()


def test_worker_passes_image_attachment_without_treating_caption_as_command(bridge):
    bind(bridge)
    bridge.media_handler = Mock()
    bridge.media_handler.prepare.return_value = ('停止', ['/private/image.png'], 'image')
    bridge.engine.submit = Mock(return_value='image submitted')
    bridge.engine.dispatch = Mock()
    assert bridge.on_message(media_event('image', {'image_key': 'img_1'}, ident='image_1'))
    assert bridge.process_one()
    bridge.engine.submit.assert_called_once_with('停止', images=['/private/image.png'])
    bridge.engine.dispatch.assert_not_called()


def test_media_error_is_replied_without_executing_codex_or_replaying(bridge):
    bind(bridge)
    bridge.media_handler = Mock()
    bridge.media_handler.prepare.side_effect = MediaError('飞书附件下载权限不足')
    bridge.engine.dispatch = Mock()
    assert bridge.on_message(media_event('audio', {'file_key': 'file_1'}, ident='audio_1'))
    assert bridge.process_one()
    bridge.engine.dispatch.assert_not_called()
    texts = [r[0] for r in bridge.store.db.execute('SELECT text FROM outbox')]
    assert any('权限不足' in x for x in texts)
    assert not bridge.process_one()


def test_resource_download_uses_message_key_and_type(tmp_path):
    client, get = client_with(b'voice')
    handler = FeishuMedia(client, tmp_path)
    assert handler.download('om_message', 'file_1', 'audio') == b'voice'
    request = get.call_args.args[0]
    assert request.message_id == 'om_message' and request.file_key == 'file_1' and request.type == 'file'
    client, get = client_with(picture())
    handler = FeishuMedia(client, tmp_path)
    handler.download('om_image', 'img_1', 'image')
    assert get.call_args.args[0].type == 'image'


def test_download_permission_and_size_failures_are_actionable(tmp_path):
    client, _ = client_with(code=99991672, msg='requires im:message:readonly')
    with pytest.raises(MediaError, match='im:message:readonly'):
        FeishuMedia(client, tmp_path).download('om_message', 'file_1', 'audio')
    client, _ = client_with(b'x' * (MAX_AUDIO_BYTES + 1))
    with pytest.raises(MediaError, match='10 MiB'):
        FeishuMedia(client, tmp_path).download('om_message', 'file_1', 'audio')


def test_image_is_real_private_png_with_safe_generated_name(tmp_path):
    client, _ = client_with(picture())
    text, paths, source = FeishuMedia(client, tmp_path).prepare('om_1', '看图', [dict(kind='image', key='img_1')])
    assert text == '看图' and source == 'image' and len(paths) == 1
    path = Path(paths[0])
    assert path.parent == tmp_path / 'attachments'
    assert path.read_bytes().startswith(b'\x89PNG\r\n\x1a\n')
    assert path.stat().st_mode & 0o777 == 0o600
    assert path.parent.stat().st_mode & 0o777 == 0o700
    with Image.open(path) as image:
        assert image.size == (64, 48)


def test_audio_uses_original_wav_and_deletes_both_original_and_decoded_file(tmp_path, monkeypatch):
    client, _ = client_with(b'original-recording')
    paths = []
    def decode(source, destination):
        assert source.read_bytes() == b'original-recording'
        assert source.stat().st_mode & 0o777 == 0o600
        paths.extend([source, destination])
        destination.write_bytes(b'RIFFtestWAV')
    def understand(path, **kwargs):
        assert kwargs['task'] == 'transcribe'
        assert path.read_bytes().startswith(b'RIFF')
        return '请回复数字七十三'
    monkeypatch.setattr('feishu_media.decode_audio', decode)
    monkeypatch.setattr('feishu_media.understand_wav', understand)
    text, images, source = FeishuMedia(client, tmp_path).prepare('om_1', '', [dict(kind='audio', key='file_1')])
    assert '数字七十三' in text and not images and source == 'feishu-direct-audio'
    assert all(not p.exists() for p in paths)


def test_audio_failure_also_removes_private_recording(tmp_path, monkeypatch):
    client, _ = client_with(b'original-recording')
    monkeypatch.setattr('feishu_media.decode_audio', lambda source, destination: destination.write_bytes(b'RIFF'))
    def fail(path, **kwargs):
        raise VoiceError('模型未完成')
    monkeypatch.setattr('feishu_media.understand_wav', fail)
    with pytest.raises(MediaError, match='模型未完成'):
        FeishuMedia(client, tmp_path).prepare('om_1', '', [dict(kind='audio', key='file_1')])
    assert list((tmp_path / 'attachments').iterdir()) == []


def test_expired_images_are_removed_except_inputs_in_active_turns(tmp_path):
    handler = FeishuMedia(None, tmp_path)
    handler.root.mkdir()
    keep, remove = handler.root / 'keep.png', handler.root / 'remove.png'
    for p in (keep, remove):
        p.write_bytes(b'image')
        os.utime(p, (0, 0))
    handler.prune_images([str(keep)])
    assert keep.exists() and not remove.exists()


def test_native_codex_turn_receives_local_image(settings_bridge):
    bridge = settings_bridge
    bind(bridge)
    bridge.engine.choose(FIRST)
    folder = bridge.directory / 'attachments'
    folder.mkdir()
    path = folder / 'test.png'
    Image.new('RGB', (8, 8), 'blue').save(path)
    bridge.engine.submit('图中有什么？', images=[str(path)])
    job = bridge.engine.jobs[FIRST]
    assert job['done'].wait(3)
    turn = next(params for method, params in SettingsRPC.calls if method == 'turn/start')
    assert turn['input'][1] == {'type': 'localImage', 'path': str(path.resolve())}
    assert '图中有什么' in turn['input'][0]['text']


def test_image_input_cannot_reference_foreign_files_or_symlinks(bridge, tmp_path):
    foreign = tmp_path / 'foreign.png'
    foreign.write_bytes(b'image')
    with pytest.raises(ValueError):
        bridge.engine.input_items('look', [str(foreign)])
    root = bridge.directory / 'attachments'
    root.mkdir()
    link = root / 'alias.png'
    link.symlink_to(foreign)
    with pytest.raises(ValueError):
        bridge.engine.input_items('look', [str(link)])


def test_image_steering_keeps_attachment_until_active_turn_finishes(bridge):
    bind(bridge)
    bridge.engine.choose(FIRST)
    folder = bridge.directory / 'attachments'
    folder.mkdir()
    path = folder / 'test.png'
    Image.new('RGB', (8, 8), 'blue').save(path)
    rpc = Mock()
    bridge.engine.jobs[FIRST] = dict(done=threading.Event(), cancel=threading.Event(),
                                   complete=threading.Event(), pending=set(), turn='turn-1',
                                   thread=FIRST, rpc=rpc, title='test', images=[])
    assert '追加' in bridge.engine.submit('再看这张图', images=[str(path)])
    assert rpc.call.call_args.args[0] == 'turn/steer'
    assert rpc.call.call_args.args[1]['input'][1]['type'] == 'localImage'
    assert bridge.engine.jobs[FIRST]['images'] == [str(path)]

"""Chinese chat commands and asynchronous, resumable Codex turns."""
from __future__ import annotations

import json
import re
import secrets
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

from bridge_state import Catalog, Store
from codex_rpc import CodexRPC, RPCError
from codex_runtime import model_settings
from mobile_format import mobile_input, render_mobile


HELP = """Houyi Codex
会话：最近会话；下一页 / 上一页
搜索 DMD：按标题查找
切换 2：选择列表第 2 个会话（列表后也可直接发 2）
当前 / 历史 / 进度 / 任务 / 语音状态：查看上下文和任务
接入状态：检查当前账号、模型和 Codex 连接
手机排版 / 完整排版：切换微信回复格式；原文：看上一条完整回复
新建 实验名称：新对话，沿用当前项目目录
收藏 / 收藏列表 / 取消收藏
命名 实验名称：设置微信端别名
上一个：切回上一个会话
分支：复制当前历史，在新会话继续
停止：中断当前会话中由微信启动的任务
归档会话：查看已归档历史

选中会话后直接发消息即可续聊；运行中发消息会追加指令。
只有完整匹配的管理口令才会被处理。要把口令原文发给 Codex，请加“说 ”，例如“说 停止”。"""


def clean_answer(text):
    return re.sub(r"<oai-mem-citation>.*?</oai-mem-citation>", "", text, flags=re.S).strip()


class SelectionRequired(ValueError):
    """A normal navigation step, not a failed Codex task."""


class Engine:
    def __init__(self, store: Store, catalog: Catalog, peer: str, rpc_factory=CodexRPC, binary="codex"):
        self.store, self.catalog, self.peer = store, catalog, peer
        self.rpc_factory, self.binary = rpc_factory, binary
        self.lock = threading.RLock()
        self.jobs = {}
        self.pending = {}

    def say(self, text, *, raw=False):
        answer = clean_answer(text)
        if not raw:
            self.store.put("last_full_reply", answer)
        shown = render_mobile(answer) if not raw and self.store.get("mobile_mode", True) else answer
        self.store.enqueue(self.peer, shown)

    def user_input(self, text):
        return mobile_input(text) if self.store.get("mobile_mode", True) else text

    def input_items(self, text, images=()):
        items = [{"type": "text", "text": self.user_input(text)}]
        attachment_root = self.store.directory / 'attachments'
        if images and attachment_root.is_symlink():
            raise ValueError('私有附件目录不能是符号链接')
        root = attachment_root.resolve()
        if len(images) > 8:
            raise ValueError('每条消息最多接收8张图片')
        for value in images:
            path = Path(value)
            if path.is_symlink() or not path.is_file() or root not in path.resolve().parents or path.suffix != '.png':
                raise ValueError('图片不属于当前入口的私有附件目录')
            items.append({"type": "localImage", "path": str(path.resolve())})
        return items

    def title(self, row):
        aliases = self.store.get("aliases", {})
        return aliases.get(row["id"]) or row.get("name") or row.get("title") or row.get("preview") or row["id"][:8]

    def name_thread(self, rpc, row, thread, text):
        """Set the initial title when an integration has a trustworthy user-supplied name."""

    def label(self, row):
        return re.sub(r"\s+", " ", self.title(row))[:80]

    def selected(self):
        ident = self.store.get("selected")
        if not ident:
            if self.store.get("menu", {}).get("ids"):
                raise SelectionRequired("还没有选中会话，这条消息尚未发送给 Codex。\n请回复刚才列表中的编号，或“切换 编号”。收到选中提示后，再发送刚才的问题。")
            raise SelectionRequired("还没有选中会话，这条消息尚未发送给 Codex。\n请先发“会话”查看列表，再回复编号选择；也可以发“新建 名称”。")
        if ident.startswith("draft:"):
            draft = self.store.get("draft:" + ident)
            if not draft:
                raise ValueError("新会话草稿已失效，请重新新建。")
            return dict(draft, id=ident)
        return self.catalog.get(ident)

    def choose(self, ident):
        previous = self.store.get("selected")
        if previous and previous != ident:
            self.store.put("previous", previous)
        self.store.put("selected", ident)
        self.store.put("awaiting_choice", False)

    def busy_label(self, ident):
        with self.lock:
            job = self.jobs.get(ident)
            if job and not job["done"].is_set():
                return "微信执行中" if not job.get("pending") else "等待你回复"
        return "桌面/其他进程占用" if self.catalog.locked(ident) else "可续聊"

    def menu(self, query="", page=0, favorite=False, archived=False):
        rows = self.catalog.rows(archived=archived)
        favs = self.store.get("favorites", [])
        if favorite:
            rows = [r for r in rows if r["id"] in favs]
        if query:
            rows = [r for r in rows if query.casefold() in " ".join(str(v or "") for v in
                    (self.title(r), r.get("title"), r.get("name"), r.get("cwd"))).casefold()]
        size = 8
        page = max(0, min(page, (max(len(rows), 1) - 1) // size))
        subset = rows[page * size:(page + 1) * size]
        self.store.put("menu", {"ids": [r["id"] for r in subset], "query": query, "page": page,
                                "favorite": favorite, "archived": archived})
        self.store.put("awaiting_choice", bool(subset))
        lines = [f"{'收藏' if favorite else '归档' if archived else '最近'}会话 · 第 {page + 1} 页 · 共 {len(rows)} 个"]
        current = self.store.get("selected")
        if not current:
            lines.append("尚未选中会话，请先回复编号选择。")
        for i, row in enumerate(subset, 1):
            date = datetime.fromtimestamp(row["updated_at"], timezone.utc).strftime("%m-%d %H:%M")
            mark = "▶ " if row["id"] == current else ""
            star = "★ " if row["id"] in favs else ""
            rel = str(row["cwd"])[len(str(self.catalog.project)):].strip("/") or "Houyi"
            lines.append(f"{i}. {mark}{star}{self.label(row)}\n   {date} UTC · {self.busy_label(row['id'])} · {rel}")
        lines.append("直接回复编号选中（也可发“切换2”或“#2”）；“下一页”；“搜索 关键词”。" if subset else "没有匹配会话。可发“会话”或“新建 名称”。")
        return "\n".join(lines)

    def resolve(self, value):
        ids = self.store.get("menu", {}).get("ids", [])
        if value.isdigit():
            index = int(value) - 1
            if not 0 <= index < len(ids):
                raise ValueError("序号不在最近一次列表里，请发“会话”重新查看。")
            return self.catalog.get(ids[index])["id"]
        rows = self.catalog.rows() + self.catalog.rows(archived=True)
        matches = [r for r in rows if r["id"].startswith(value) or self.title(r) == value]
        if len(matches) != 1:
            raise ValueError("没有唯一匹配，请先“搜索 关键词”，再按序号切换。")
        return matches[0]["id"]

    def current(self):
        row = self.selected()
        state = "新会话，等待首条消息" if row["id"].startswith("draft:") else self.busy_label(row["id"])
        model = row.get("model") or "沿用 Codex 配置"
        effort = row.get("reasoning_effort") or "默认"
        if state == "桌面/其他进程占用":
            tip = "可发“历史”查看最近对话。要立刻继续聊，请发“分支”；收到创建成功的回复后，再发送问题。原会话保留。"
        elif state == "等待你回复":
            tip = "请按上一条请求的编号回复；可发“进度”查看当前状态。"
        else:
            tip = "直接发消息即可继续；发“历史”查看最近对话。"
        return f"当前：{self.label(row)}\n目录：{row['cwd']}\n模型：{model} / {effort}\n状态：{state}\n{tip}"

    def dispatch(self, text):
        try:
            return self._dispatch(text)
        except SelectionRequired as exc:
            return str(exc)

    def _dispatch(self, text):
        text = text.strip()
        if not text:
            return "当前支持文字指令和微信已经转写的语音。请发送文字。"
        if len(text) > 32000:
            return "这条消息过长，请拆成几条发送。"
        if text.startswith("说 "):
            return self.submit(text[2:])
        command = text[1:] if text.startswith("/") else text
        if command in {"手机排版", "完整排版"}:
            mobile = command == "手机排版"
            self.store.put("mobile_mode", mobile)
            return "微信回复已改为" + ("手机排版。需要上一条完整内容可发“原文”。" if mobile else "完整排版；发“手机排版”可恢复。")
        if command == "原文":
            return self.store.get("last_full_reply") or "还没有可查看的上一条回复。"
        if command in {"帮助", "菜单", "help", "start"}:
            return HELP
        if command in {"会话", "会话列表", "sessions"}:
            return self.menu()
        if command in {"收藏列表", "归档会话"}:
            return self.menu(favorite=command == "收藏列表", archived=command == "归档会话")
        if command in {"下一页", "上一页"}:
            menu = self.store.get("menu", {})
            return self.menu(menu.get("query", ""), menu.get("page", 0) + (1 if command == "下一页" else -1),
                             menu.get("favorite", False), menu.get("archived", False))
        if command.startswith("搜索 "):
            return self.menu(query=command[3:].strip())
        if command.isdigit() and (self.store.get("awaiting_choice", False) or
                                  (not self.store.get("selected") and self.store.get("menu", {}).get("ids"))):
            self.choose(self.resolve(command))
            return self.current()
        match = re.fullmatch(r"(?:切换\s+|#)(.+)", command) or re.fullmatch(r"(?:切换|选择|进入)\s*(\d+)", command)
        if match:
            self.choose(self.resolve(match[1].strip()))
            return self.current()
        if command == "上一个":
            previous = self.store.get("previous")
            if not previous:
                return "还没有上一个会话。"
            if not previous.startswith("draft:"):
                self.catalog.get(previous)
            self.choose(previous)
            return self.current()
        if command in {"当前", "状态"}:
            return self.current()
        if command == "接入状态":
            rpc = self.rpc_factory(self.catalog.home, self.catalog.project, binary=self.binary)
            try:
                account = rpc.call("account/read", {}).get("account") or {}
                settings = model_settings(rpc, {})
                kind = "ChatGPT 个人/工作账号" if account.get("type") == "chatgpt" else account.get("type") or "自定义提供商"
                return (f"Codex 接入正常\n账号：{kind}\n提供商：{settings['modelProvider']}\n"
                        f"模型：{settings['model']} / {settings['effort'] or '默认'}\n"
                        "选中会话后直接发送任务；桌面占用的会话可发“分支”继续。")
            finally:
                rpc.close()
        if command == "语音状态":
            row = self.store.get("last_voice") or {}
            labels = {"direct-audio": "原音由本地音频模型理解",
                      "feishu-direct-audio": "飞书原音由本地音频模型理解",
                      "wechat-transcript-fallback": "原音处理失败，已用微信转写",
                      "error": "原音与转写均不可用"}
            return "最近一条语音：" + labels.get(row.get("source"), "尚未处理语音")
        if command == "历史":
            row = self.selected()
            if row["id"].startswith("draft:"):
                return "新会话还没有历史。"
            entries = self.catalog.history(row["id"], limit=6)
            return "【" + self.label(row) + "】最近对话\n\n" + "\n\n".join(
                ("你：" if role == "user" else "Codex：") + clean_answer(body)[:1800] + ("…" if len(body) > 1800 else "")
                for role, body in entries)
        if command == "新建" or command.startswith("新建 "):
            try:
                cwd = self.selected()["cwd"]
            except ValueError:
                cwd = str(self.catalog.project)
            ident = "draft:" + secrets.token_hex(8)
            self.store.put("draft:" + ident, {"cwd": cwd, "title": command[2:].strip() or "微信新会话"})
            self.choose(ident)
            return self.current()
        if command in {"收藏", "取消收藏"}:
            row = self.selected()
            if row["id"].startswith("draft:"):
                return "请先发首条消息，建立会话后再收藏。"
            favorites = set(self.store.get("favorites", []))
            (favorites.add if command == "收藏" else favorites.discard)(row["id"])
            self.store.put("favorites", sorted(favorites))
            return f"已{'收藏' if command == '收藏' else '取消收藏'}：{self.label(row)}"
        if command.startswith("命名 "):
            row = self.selected()
            aliases = self.store.get("aliases", {})
            aliases[row["id"]] = command[3:].strip()[:120]
            self.store.put("aliases", aliases)
            return "微信端会话名称已更新：" + aliases[row["id"]]
        if command in {"进度", "任务"}:
            return self.progress(all_tasks=command == "任务")
        if command == "停止":
            return self.stop_job(self.selected()["id"])
        if command == "分支":
            return self.submit(None, fork=True)
        match = re.fullmatch(r"(批准|拒绝|回答)\s+([0-9a-f]{8})(?:\s+([\s\S]+))?", command)
        if match:
            return self.respond(match[1], match[2], match[3] or "")
        if text.startswith("/"):
            return "没有这个管理口令。发“帮助”查看；用“说 ”前缀可原样发给 Codex。"
        return self.submit(text)

    def stop_job(self, ident, *, expected_started=None):
        with self.lock:
            job = self.jobs.get(ident)
            if not job or job["done"].is_set():
                return "当前会话没有正在执行的任务。"
            if expected_started is not None and job["started"] != expected_started:
                return "点击时的任务已结束，当前新任务继续执行。"
            if job["cancel"].is_set():
                return "已请求中断，请等待“已中断”后发送新任务。"
            job["cancel"].set()
            rpc, thread, turn = job.get("rpc"), job.get("thread"), job.get("turn")
        if rpc and turn:
            rpc.call("turn/interrupt", {"threadId": thread, "turnId": turn})
        return "已请求中断，请等待“已中断”后发送新任务。"

    def progress(self, all_tasks=False):
        selected = None if all_tasks else self.selected()["id"]
        tasks = self.store.get("tasks", {})
        lines = []
        for ident, task in reversed(list(tasks.items())):
            if selected and ident != selected:
                continue
            status = {"starting": "启动中", "running": "运行中", "waiting": "等待你回复", "completed": "已完成",
                      "failed": "未完成", "interrupted": "已中断"}.get(task["status"], task["status"])
            lines.append(f"【{task.get('title', ident[:8])}】{status}\n{task.get('progress', '')[:1500]}")
            if len(lines) == 8:
                break
        return "\n\n".join(lines) or "微信端还没有执行记录。可发“历史”查看已有对话。"

    def save_job(self, job):
        with self.lock:
            tasks = self.store.get("tasks", {})
            temporary = job.get("persist_key", job["key"])
            ident = job.get("thread") or temporary
            if ident != temporary and temporary.startswith(("draft:", "branch:")):
                tasks.pop(temporary, None)
            tasks[ident] = {k: job.get(k) for k in ("title", "status", "progress", "started", "turn")}
            self.store.put("tasks", dict(list(tasks.items())[-100:]))

    def submit(self, text, fork=False, *, images=None):
        images = list(images or [])
        input_items = self.input_items(text, images)
        self.store.put("awaiting_choice", False)
        row = self.selected()
        key = row["id"]
        with self.lock:
            active = self.jobs.get(key)
        if active and not active["done"].is_set():
            if active["cancel"].is_set():
                return "上一轮正在中断，请等待“已中断”后重新发送新任务；这条消息尚未提交。"
            if active.get("complete") and active["complete"].is_set():
                return "上一轮正在收尾，请稍后重新发送；这条消息尚未提交。"
            if fork:
                raise ValueError("请等待当前微信任务完成后再分支。")
            if active.get("pending"):
                return "Codex 正在等待你的回复，请按上一条提示发送“回答 编号 内容”或“批准/拒绝 编号”。"
            if not active.get("turn"):
                return "会话正在接续，请稍后再发；这条追加消息尚未提交。"
            # Never hold the engine lock while waiting on the reader's RPC response.
            active["rpc"].call("turn/steer", {"threadId": active["thread"], "expectedTurnId": active["turn"],
                                            "input": input_items})
            if images:
                with self.lock:
                    active.setdefault('images', []).extend(images)
            return f"已向【{active['title']}】追加指令。"
        with self.lock:
            if sum(not j["done"].is_set() for j in self.jobs.values()) >= 3:
                return "已有 3 个微信任务运行中，请先查看“任务”。"
            if not key.startswith("draft:") and not fork and self.catalog.locked(key):
                return ("这个会话正被桌面或其他进程占用。可以继续查看“历史”；关闭桌面端对此会话的占用后再发消息，"
                        "或发“分支”复制已有历史，在新会话继续。原会话会保留。")
            if fork and key.startswith("draft:"):
                return "新会话还没有历史可以分支。"
            job = {"key": key, "title": self.label(row), "status": "starting", "progress": "正在接续会话",
                   "started": time.time(), "done": threading.Event(), "complete": threading.Event(),
                   "cancel": threading.Event(), "pending": set(), "items": {}, "last_push": 0, "final": ""}
            job['input_items'] = input_items
            job['images'] = images
            if fork:
                job["persist_key"] = "branch:" + secrets.token_hex(8)
            self.jobs[key] = job
            self.save_job(job)
            worker = threading.Thread(target=self.run_job, args=(job, row, text, fork), daemon=True)
            job["worker"] = worker
            worker.start()
        return f"正在{'创建分支' if fork else '处理'}：【{job['title']}】。可发“进度”查询。"

    def runtime_settings(self, rpc, row):
        return model_settings(rpc, row)

    def thread_ready(self, row, result, settings):
        pass

    def run_job(self, job, row, text, fork):
        rpc = None
        try:
            rpc = self.rpc_factory(self.catalog.home, row["cwd"], callback=lambda m: self.on_event(job, m), binary=self.binary)
            job["rpc"] = rpc
            settings = self.runtime_settings(rpc, row)
            overrides = {"model": settings["model"], "modelProvider": settings["modelProvider"]}
            if settings["effort"]:
                overrides["config"] = {"model_reasoning_effort": settings["effort"]}
            overrides.update(settings.get("threadOverrides", {}))
            if fork:
                result = rpc.call("thread/fork", {"threadId": row["id"], "excludeTurns": True, **overrides})
            elif row["id"].startswith("draft:"):
                result = rpc.call("thread/start", {"cwd": row["cwd"], "sandbox": "workspace-write", "approvalPolicy": "on-request", **overrides})
            else:
                if row.get("archived"):
                    rpc.call("thread/unarchive", {"threadId": row["id"]})
                result = rpc.call("thread/resume", {"threadId": row["id"], "excludeTurns": True, **overrides})
            thread = result["thread"]
            if not self.catalog.scoped(thread.get("cwd")):
                raise ValueError("Codex 返回了工作目录范围以外的会话，已停止。")
            self.thread_ready(row, result, settings)
            ident = thread["id"]
            if row["id"].startswith("draft:") and isinstance(text, str) and text.strip():
                if self.name_thread(rpc, row, thread, text):
                    job["title"] = self.label({**thread, "id": ident, "cwd": row["cwd"]})
            with self.lock:
                job["thread"] = ident
                self.jobs.pop(job["key"], None)
                self.jobs[ident] = job
                if ident != row["id"]:
                    aliases = self.store.get("aliases", {})
                    aliases[ident] = aliases.get(row["id"], job["title"]) + (" · 微信分支" if fork else "")
                    job["title"] = aliases[ident]
                    self.store.put("aliases", aliases)
                    if self.store.get("selected") == row["id"]:
                        self.choose(ident)
                job["status"] = "running"
                self.save_job(job)
            if fork:
                job["status"] = "completed"
                self.say(f"已创建并选中【{job['title']}】。原会话保留，请直接发送下一条指令。")
                return
            if job["cancel"].is_set():
                job["status"] = "interrupted"
                self.say(f"【{job['title']}】已中断，尚未开始执行。")
                return
            if settings["previousModel"]:
                self.say(f"【{job['title']}】原模型 {settings['previousModel']} 不在当前账号可用列表中，本轮使用 {settings['model']}。")
            turn_params = {"threadId": ident, "model": settings["model"],
                           "input": job.get('input_items') or self.input_items(text)}
            if settings["effort"]:
                turn_params["effort"] = settings["effort"]
            turn_params.update(settings.get("turnOverrides", {}))
            result = rpc.call("turn/start", turn_params)
            job["turn"] = result["turn"]["id"]
            if job["cancel"].is_set():
                rpc.call("turn/interrupt", {"threadId": ident, "turnId": job["turn"]})
            self.save_job(job)
            while not job["complete"].wait(1):
                if rpc.proc.poll() is not None:
                    raise RPCError("Codex 连接中断，请查看历史后继续；任务不会自动重跑。")
            if job.get("error"):
                raise RPCError(job["error"])
            final = job.get("final") or job.get("last_message") or "本轮已结束，没有文字回复。"
            self.say(f"【{job['title']}】{'已中断' if job['status'] == 'interrupted' else '完成'}\n\n{final}")
        except Exception as exc:
            job["status"] = "failed"
            job["progress"] = str(exc)[:2000]
            self.say(f"【{job['title']}】未完成：{job['progress']}\n可发“历史”核对后再继续。")
        finally:
            if rpc:
                rpc.close()  # Release only our own writer lock after every completed turn.
            with self.lock:
                for pending in list(job["pending"]):
                    self.pending.pop(pending, None)
                job["pending"].clear()
                self.save_job(job)
                job["done"].set()

    def on_event(self, job, message):
        method = message.get("method", "")
        p = message.get("params") or {}
        if "id" in message:
            token = secrets.token_hex(4)
            if method in {"item/commandExecution/requestApproval", "item/fileChange/requestApproval",
                          "item/permissions/requestApproval", "tool/requestUserInput", "mcpServer/elicitation/request"}:
                with self.lock:
                    self.pending[token] = (job, message)
                    job["pending"].add(token)
                    job["status"] = "waiting"
                if method == "tool/requestUserInput":
                    questions = p.get("questions", [])
                    detail = "\n".join(q.get("question", "") + "\n" + " / ".join(o.get("label", "") for o in q.get("options", [])) for q in questions)
                    suffix = f"回复：回答 {token} 你的答案" + ("（多题按顺序用 | 分隔）" if len(questions) > 1 else "")
                elif method == "mcpServer/elicitation/request":
                    detail = p.get("message", "") + "\n" + json.dumps(p.get("requestedSchema", {}), ensure_ascii=False)
                    suffix = f"回复：回答 {token} JSON内容，或：拒绝 {token}"
                else:
                    if method == "item/commandExecution/requestApproval":
                        detail = f"命令：{p.get('command', '未提供')}\n目录：{p.get('cwd', '')}\n原因：{p.get('reason') or '需要执行授权'}"
                    elif method == "item/fileChange/requestApproval":
                        changes = job.get("items", {}).get(p.get("itemId"), {}).get("changes")
                        detail = f"文件变更：{p.get('reason') or ''}\n" + (json.dumps(changes, ensure_ascii=False) if changes else "缺少文件变更详情，暂不能在微信批准。")
                    else:
                        detail = "请求权限：" + json.dumps(p.get("permissions", {}), ensure_ascii=False) + "\n" + (p.get("reason") or "")
                    suffix = f"回复：批准 {token} 或 拒绝 {token}（仅此次）"
                job["progress"] = detail[:2000]
                self.save_job(job)
                self.say(f"【{job['title']}】需要你回复 · {token}\n{detail}\n{suffix}")
            else:
                job["rpc"].send({"id": message["id"], "error": {"code": -32601, "message": "WeChat client does not support this request"}})
            return
        if method == "bridge/disconnected":
            if not job["complete"].is_set():
                job["error"] = "Codex 连接已断开"
                job["complete"].set()
        elif method == "turn/started":
            job["turn"] = p.get("turn", {}).get("id")
        elif method == "item/started":
            item = p.get("item", {})
            if item.get("type") == "fileChange":
                job.setdefault("items", {})[item["id"]] = item
        elif method == "item/completed":
            item = p.get("item", {})
            if item.get("type") == "agentMessage":
                body = item.get("text", "")
                job["last_message"] = body
                if item.get("phase") in {"final", "final_answer"}:
                    job["final"] = body
                else:
                    job["progress"] = body[-2000:]
                    if time.time() - job["last_push"] > 90:
                        self.say(f"【{job['title']}】进展\n{body[:2500]}")
                        job["last_push"] = time.time()
                self.save_job(job)
        elif method == "turn/completed":
            turn = p.get("turn", {})
            job["status"] = turn.get("status", "completed")
            job["progress"] = (job.get("final") or job.get("last_message") or "本轮结束")[-2000:]
            job["error"] = str(turn["error"]) if turn.get("error") else None
            self.save_job(job)
            job["complete"].set()

    def respond(self, action, token, text):
        with self.lock:
            found = self.pending.get(token)
        if not found:
            return "这个请求已结束或编号不正确，请查看“进度”。"
        job, message = found
        p, method = message.get("params", {}), message["method"]
        if method == "tool/requestUserInput":
            if action != "回答":
                return f"请用“回答 {token} 内容”。"
            questions = p.get("questions", [])
            answers = [v.strip() for v in text.split("|")] if len(questions) > 1 else [text]
            if len(answers) != len(questions) or not all(answers):
                return "请按问题顺序回答，多题答案用 | 分隔。"
            result = {"answers": {q["id"]: {"answers": [a]} for q, a in zip(questions, answers)}}
        elif method == "mcpServer/elicitation/request":
            if action == "拒绝":
                result = {"action": "decline", "content": None}
            elif action == "回答":
                result = {"action": "accept", "content": json.loads(text)}
            else:
                return "请用“回答 编号 JSON内容”或“拒绝 编号”。"
        elif method == "item/permissions/requestApproval":
            if action not in {"批准", "拒绝"}:
                return "请发送批准或拒绝。"
            result = {"permissions": p.get("permissions", {}) if action == "批准" else {}, "scope": "turn"}
        else:
            if action not in {"批准", "拒绝"}:
                return "请发送批准或拒绝。"
            if action == "批准" and method == "item/fileChange/requestApproval" and not job.get("items", {}).get(p.get("itemId"), {}).get("changes"):
                return "缺少文件变更详情，不能批准。请拒绝该请求或在桌面查看处理。"
            choices = p.get("availableDecisions", [])
            decision = "accept" if action == "批准" else ("cancel" if choices and "decline" not in choices else "decline")
            result = {"decision": decision}
        job["rpc"].send({"id": message["id"], "result": result})
        with self.lock:
            self.pending.pop(token, None)
            job["pending"].discard(token)
            job["status"] = "running" if not job["pending"] else "waiting"
            self.save_job(job)
        return f"已回复【{job['title']}】的请求 {token}。"

    def close(self):
        with self.lock:
            jobs = list(self.jobs.values())
        for job in jobs:
            if job["done"].is_set():
                continue
            job["cancel"].set()
            if job.get("rpc") and job.get("turn"):
                try:
                    job["rpc"].call("turn/interrupt", {"threadId": job["thread"], "turnId": job["turn"]}, timeout=5)
                except RPCError:
                    pass
        for job in jobs:
            job["worker"].join(timeout=8)
            if not job["done"].is_set() and job.get("rpc"):
                job["rpc"].close()

"""Private Feishu attachments: original-audio understanding and Codex images."""
from __future__ import annotations

import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import time
import wave

from voice_understanding import VoiceError, understand_wav

MAX_AUDIO_BYTES = 10 * 1024 * 1024
MAX_IMAGE_BYTES = 20 * 1024 * 1024
MAX_AUDIO_SECONDS = 300
MAX_IMAGES = 8
MAX_CACHE_BYTES = 1024 * 1024 * 1024
IMAGE_RETENTION_SECONDS = 7 * 24 * 3600


class MediaError(RuntimeError):
    pass


def resource_key(value):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,300}', value):
        raise ValueError('飞书附件标识无效')
    return value


def incoming_content(kind, content):
    """Extract only documented media keys; never accept caller-provided URLs/paths."""
    if not isinstance(content, dict):
        raise ValueError('飞书消息内容无效')
    if kind == 'text':
        text = content.get('text', '')
        if not isinstance(text, str):
            raise ValueError('飞书文字消息无效')
        return text, []
    if kind == 'image':
        return '请查看我发送的图片。', [dict(kind='image', key=resource_key(content.get('image_key')))]
    if kind == 'audio':
        return '', [dict(kind='audio', key=resource_key(content.get('file_key')))]
    if kind != 'post':
        raise ValueError('暂不支持此飞书消息类型')
    post = content if 'content' in content else content.get('zh_cn') or content.get('en_us')
    if not isinstance(post, dict) or not isinstance(post.get('content'), list):
        raise ValueError('飞书图文消息格式无效')
    lines = [post['title']] if isinstance(post.get('title'), str) and post['title'] else []
    images = []
    for row in post['content']:
        if not isinstance(row, list):
            raise ValueError('飞书图文消息行无效')
        texts = []
        for item in row:
            if not isinstance(item, dict):
                raise ValueError('飞书图文消息元素无效')
            if item.get('tag') in {'text', 'a', 'code_block', 'md'}:
                text = item.get('text', '')
                if not isinstance(text, str):
                    raise ValueError('飞书图文文字无效')
                texts.append(text)
            elif item.get('tag') == 'img':
                key = resource_key(item.get('image_key'))
                if key not in [x['key'] for x in images]:
                    images.append(dict(kind='image', key=key))
            elif item.get('tag') not in {'at', 'emotion', 'hr'}:
                raise ValueError('这条图文包含尚未支持的附件，请单独发送图片或语音')
        if texts:
            lines.append(''.join(texts))
    if len(images) > MAX_IMAGES:
        raise ValueError(f'每条消息最多接收 {MAX_IMAGES} 张图片，请分开发送')
    return '\n'.join(lines).strip() or '请查看我发送的图片。', images


def decode_audio(source, destination):
    executable = shutil.which('ffmpeg')
    if not executable:
        candidate = Path('/aigc/avatar/houyi/miniforge3/envs/multitalk/bin/ffmpeg')
        executable = str(candidate) if candidate.is_file() else None
    if not executable:
        raise MediaError('缺少语音解码器')
    try:
        subprocess.run([executable, '-nostdin', '-v', 'error', '-threads', '2',
                        '-protocol_whitelist', 'file,pipe', '-i', str(source), '-map', '0:a:0', '-t', str(MAX_AUDIO_SECONDS + 1),
                        '-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le', '-y', str(destination)],
                       check=True, timeout=45, capture_output=True)
        with wave.open(str(destination), 'rb') as audio:
            duration = audio.getnframes() / audio.getframerate()
        if not 0 < duration <= MAX_AUDIO_SECONDS:
            raise MediaError('语音为空或超过5分钟，请分段发送；没有截断后执行')
    except (subprocess.SubprocessError, OSError, wave.Error):
        raise MediaError('这条语音无法解码，请用飞书录音重新发送') from None
    return duration


class FeishuMedia:
    def __init__(self, client, directory):
        self.client = client
        self.directory = Path(directory)
        self.root = self.directory / 'attachments'

    def download(self, message_id, key, kind):
        from lark_oapi.api.im.v1 import GetMessageResourceRequest
        request = GetMessageResourceRequest.builder().message_id(message_id).file_key(resource_key(key)).type('image' if kind == 'image' else 'file').build()
        try:
            response = self.client.im.v1.message_resource.get(request)
        except Exception:
            raise MediaError('飞书附件下载暂时失败，请稍后重发') from None
        if not response.success():
            scopes = sorted(set(re.findall(r'im:[a-zA-Z0-9_.:]+', str(response.msg or ''))))
            details = ('；需要权限：' + '、'.join(scopes)) if scopes else ''
            raise MediaError(f'飞书附件下载失败（错误码 {response.code}）{details}。请在飞书开放平台检查消息资源读取权限。')
        if response.file is None:
            raise MediaError('飞书返回了空附件')
        limit = MAX_IMAGE_BYTES if kind == 'image' else MAX_AUDIO_BYTES
        try:
            data = response.file.read(limit + 1)
        finally:
            response.file.close()
        if not data or len(data) > limit:
            raise MediaError(f'附件为空或超过 {limit // (1024 * 1024)} MiB，请缩小后发送')
        return data

    def prune_images(self, protected):
        protected = {str(Path(p).resolve()) for p in protected}
        total = 0
        for path in self.root.glob('*.png'):
            if path.is_symlink():
                continue
            stat = path.stat()
            if time.time() - stat.st_mtime > IMAGE_RETENTION_SECONDS and str(path.resolve()) not in protected:
                path.unlink()
            else:
                total += stat.st_size
        if total >= MAX_CACHE_BYTES:
            raise MediaError('私有图片缓存已达1 GiB，需要清理旧图片后再发送')

    def save_image(self, raw, message_id, key):
        from PIL import Image, ImageOps
        try:
            with Image.open(io.BytesIO(raw)) as image:
                if image.format not in {'PNG', 'JPEG', 'WEBP', 'GIF'} or image.width * image.height > 32_000_000:
                    raise MediaError('图片格式或像素数量不支持，请发送 PNG/JPEG/WebP 或 GIF 首帧')
                image.seek(0)
                image = ImageOps.exif_transpose(image).convert('RGB')
                image.thumbnail((4096, 4096))
                encoded = io.BytesIO()
                image.save(encoded, format='PNG')
                data = encoded.getvalue()
        except (OSError, ValueError, Image.DecompressionBombError):
            raise MediaError('图片解码失败，请重新发送原图') from None
        if len(data) > MAX_IMAGE_BYTES:
            raise MediaError('解码后的图片超过20 MiB，请缩小后发送')
        name = hashlib.sha256((message_id + '\0' + key).encode()).hexdigest() + '.png'
        path = self.root / name
        used = sum(p.stat().st_size for p in self.root.glob('*.png') if not p.is_symlink())
        if used - (path.stat().st_size if path.exists() else 0) + len(data) > MAX_CACHE_BYTES:
            raise MediaError('私有图片缓存已达1 GiB，需要清理旧图片后再发送')
        fd, temporary = tempfile.mkstemp(prefix='image-', suffix='.tmp', dir=self.root)
        try:
            with os.fdopen(fd, 'wb') as out:
                out.write(data)
            os.replace(temporary, path)
        finally:
            Path(temporary).unlink(missing_ok=True)
        return str(path.resolve())

    def prepare(self, message_id, text, media, protected=()):
        if self.root.is_symlink():
            raise MediaError('私有附件目录不能是符号链接')
        self.root.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.root.chmod(0o700)
        if any(item['kind'] == 'image' for item in media):
            self.prune_images(protected)
        images = []
        source = 'text'
        for item in media:
            kind, key = item['kind'], item['key']
            raw = self.download(message_id, key, kind)
            if kind == 'image':
                images.append(self.save_image(raw, message_id, key))
                source = 'image'
            elif kind == 'audio':
                with tempfile.TemporaryDirectory(prefix='voice-', dir=self.root) as temporary:
                    folder = Path(temporary)
                    recording, wav = folder / 'original.audio', folder / 'voice.wav'
                    recording.write_bytes(raw)
                    recording.chmod(0o600)
                    decode_audio(recording, wav)
                    try:
                        understood = understand_wav(wav, task='transcribe')
                    except VoiceError as exc:
                        raise MediaError(str(exc)) from None
                text = '【飞书语音原音转写】' + understood
                if '[听不清]' in understood:
                    text += '\n录音有听不清的部分；涉及姓名、路径或数字时请先澄清，再执行请求。'
                source = 'feishu-direct-audio'
            else:
                raise MediaError('附件类型不支持')
        return text, images, source

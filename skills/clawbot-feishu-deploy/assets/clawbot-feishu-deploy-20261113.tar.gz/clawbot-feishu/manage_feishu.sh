#!/usr/bin/env bash
set -euo pipefail
umask 077
bridge_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
state_dir="${CODEX_FEISHU_STATE:-/aigc/avatar/houyi/.codex-feishu-bridge-state}"
export CODEX_HOME="${CODEX_HOME:-/aigc/avatar/houyi/restart_commands_h200/migrate_materials/.codex}"
export CODEX_FEISHU_STATE="$state_dir"
export CODEX_BRIDGE_PROJECT="${CODEX_BRIDGE_PROJECT:-/aigc/avatar/houyi}"
mkdir -p "$state_dir"
chmod 700 "$state_dir"
cd "$bridge_dir"
case "${1:-status}" in
  configure)
    exec "$bridge_dir/.venv_feishu/bin/python" configure_feishu.py
    ;;
  start)
    if [[ ! -f "$state_dir/config.json" ]]; then
      echo '尚未配置飞书应用。先运行 bash manage_feishu.sh configure。' >&2
      exit 2
    fi
    if tmux has-session -t '=houyi-feishu-codex' 2>/dev/null; then
      echo '飞书服务已运行。'
    else
      tmux new-session -d -s houyi-feishu-codex -c "$bridge_dir" \
        -e "CODEX_HOME=$CODEX_HOME" -e "CODEX_FEISHU_STATE=$state_dir" \
        -e "CODEX_BRIDGE_PROJECT=$CODEX_BRIDGE_PROJECT" -e "CODEX_BRIDGE_BIN=${CODEX_BRIDGE_BIN:-codex}" \
        "exec '$bridge_dir/.venv_feishu/bin/python' -u '$bridge_dir/feishu_bot.py' serve >>'$state_dir/service.log' 2>&1"
      echo '飞书服务已启动，请用 status 核验长连接状态。'
    fi
    ;;
  status)
    exec "$bridge_dir/.venv_feishu/bin/python" feishu_bot.py status
    ;;
  stop)
    if tmux has-session -t '=houyi-feishu-codex' 2>/dev/null; then
      tmux send-keys -t '=houyi-feishu-codex:0.0' C-c
      echo '已请求飞书桥接退出。'
    fi
    ;;
  *) echo '用法: manage_feishu.sh configure|start|status|stop' >&2; exit 2 ;;
esac

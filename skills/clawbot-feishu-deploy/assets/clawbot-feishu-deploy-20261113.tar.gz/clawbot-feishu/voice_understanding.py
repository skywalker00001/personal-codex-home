"""Decrypt Weixin voice media and infer intent from the original recording.

All audio lives in a mode-0700 temporary directory and is removed after each
command. The model does not receive the Weixin transcription.
"""
from __future__ import annotations

import base64
import json
import os
import subprocess
import tempfile
from pathlib import Path
from urllib.parse import quote, urlparse

import requests
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

CDN_BASE = "https://novac2c.cdn.weixin.qq.com/c2c"
MAX_MEDIA_BYTES = 10 * 1024 * 1024
PROJECT = Path(__file__).resolve().parent


class VoiceError(RuntimeError):
    pass


def understand_wav(wav_path: Path, *, task='intent') -> str:
    """Shared original-audio understanding for Weixin and Feishu; no transcript."""
    if not (PROJECT / '.venv_audio' / 'bin' / 'python').is_file():
        raise VoiceError('缺少本地音频模型环境')
    if task not in {'intent', 'transcribe'}:
        raise ValueError('Unknown audio task')
    try:
        proc = subprocess.run([str(PROJECT / '.venv_audio' / 'bin' / 'python'),
                               str(PROJECT / 'voice_model_cpu.py'), str(wav_path), '--task', task],
                              check=True, timeout=300, capture_output=True, text=True,
                              env=dict(os.environ, TRANSFORMERS_VERBOSITY='error',
                                       CUDA_VISIBLE_DEVICES='', HF_HUB_OFFLINE='1',
                                       TRANSFORMERS_OFFLINE='1'))
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, OSError):
        raise VoiceError('本地原音理解未完成，请把较长录音分段后重试') from None
    intent = proc.stdout.strip()
    if not intent:
        raise VoiceError('本地模型未返回语音意图')
    return intent[:3000]


def voice_url(media: dict) -> str:
    url = media.get("full_url") or ""
    if not url and media.get("encrypt_query_param"):
        url = CDN_BASE + "/download?encrypted_query_param=" + quote(media["encrypt_query_param"], safe="")
    parsed = urlparse(url)
    host = parsed.hostname or ""
    if (parsed.scheme != "https" or not (host == "weixin.qq.com" or host.endswith(".weixin.qq.com"))
            or parsed.username or parsed.password or parsed.port not in (None, 443) or parsed.fragment):
        raise VoiceError("微信返回了不可信的语音下载地址")
    return url


def decrypt_voice(voice: dict) -> bytes:
    media = voice.get("media") or {}
    if not media.get("aes_key"):
        raise VoiceError("微信没有提供原音解密密钥")
    url = voice_url(media)
    try:
        response = requests.get(url, timeout=(10, 35), stream=True, allow_redirects=False)
        if response.status_code != 200:
            raise VoiceError(f"微信录音下载 HTTP {response.status_code}")
        parts = bytearray()
        for block in response.iter_content(64 * 1024):
            parts.extend(block)
            if len(parts) > MAX_MEDIA_BYTES:
                raise VoiceError("微信录音超过大小限制")
        raw_key = base64.b64decode(media["aes_key"], validate=True)
        key = bytes.fromhex(raw_key.decode("ascii")) if len(raw_key) == 32 else raw_key
        if len(key) != 16:
            raise VoiceError("微信录音密钥格式无效")
        decryptor = Cipher(algorithms.AES(key), modes.ECB()).decryptor()
        padded = decryptor.update(parts) + decryptor.finalize()
        unpadder = padding.PKCS7(128).unpadder()
        silk = unpadder.update(padded) + unpadder.finalize()
        if not silk.startswith((b"#!SILK_V3", b"\x02#!SILK_V3")):
            raise VoiceError("微信录音不是可解码的 SILK 音频")
        return silk
    except requests.RequestException:
        raise VoiceError("微信原音下载失败") from None
    except (ValueError, UnicodeError) as exc:
        raise VoiceError("微信原音解密失败") from None


def understand_voice(voice: dict, private_dir: Path) -> str:
    if not (PROJECT / "node_modules" / "silk-wasm").is_dir():
        raise VoiceError("缺少 SILK 解码器")
    if not (PROJECT / ".venv_audio" / "bin" / "python").is_file():
        raise VoiceError("缺少本地音频模型环境")
    silk = decrypt_voice(voice)
    os.umask(0o077)
    with tempfile.TemporaryDirectory(prefix="voice-", dir=private_dir) as temp:
        work = Path(temp)
        raw_path, wav_path = work / "voice.silk", work / "voice.wav"
        raw_path.write_bytes(silk)
        rate = int(voice.get("sample_rate") or 24000)
        if rate not in (8000, 12000, 16000, 24000, 32000, 48000):
            rate = 24000
        try:
            subprocess.run(["node", str(PROJECT / "decode_silk.mjs"), str(raw_path), str(wav_path), str(rate)],
                           check=True, timeout=30, capture_output=True)
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired, OSError):
            raise VoiceError("本地原音理解未完成") from None
        return understand_wav(wav_path)


def voice_to_command(message: dict, private_dir: Path) -> tuple[str, str]:
    """Return input for Codex and a non-sensitive status label for logging."""
    transcript = "\n".join(text for item in message.get("item_list", [])
                           for text in [((item.get("text_item") or {}).get("text", "")
                                         if item.get("type") == 1 else
                                         (item.get("voice_item") or {}).get("text", "")
                                         if item.get("type") == 3 else "")]
                           if text)
    voices = [item.get("voice_item") or {} for item in message.get("item_list", []) if item.get("type") == 3]
    if not voices:
        return transcript, "text"
    try:
        understood = understand_voice(voices[0], private_dir)
    except VoiceError:
        if not transcript:
            return "这条语音的原音无法处理，微信也没有提供转写。请重新发送。", "error"
        return transcript, "wechat-transcript-fallback"
    if transcript and transcript.strip() != understood.strip():
        return (f"【原音理解】{understood}\n【微信转写供校对】{transcript}\n"
                "如果两者在姓名、命令或数字上不一致，请先询问用户。"), "direct-audio"
    return f"【原音理解】{understood}", "direct-audio"

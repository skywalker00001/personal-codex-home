import json
import sqlite3

import pytest

from feishu_history import readable_text
from test_feishu import FIRST, SECOND, bind, bridge, button_value, callback, message


def walk(element):
    yield element
    for name in ('elements', 'columns'):
        for child in element.get(name, []):
            yield from walk(child)


def nodes(card):
    return list(walk(card['body']))


def label(node):
    return node.get('content') or node.get('text', {}).get('content', '')


def buttons(card):
    return [node for node in nodes(card) if node.get('tag') == 'button']


def setup_history(bridge, monkeypatch, entries):
    bind(bridge)
    monkeypatch.setattr(bridge.engine.catalog, 'history', lambda ident, limit=None: list(entries))
    return bridge


def test_history_uses_distinct_roles_complete_rounds_and_one_persisted_card(bridge, monkeypatch):
    entries = [('user', '我的第一个问题'), ('assistant', '第一个答案')]
    for index in range(1, 5):
        entries.extend([('user', f'问题 {index}\n\n第二段'), ('assistant', f'**回答 {index}**\n\n- 项目甲\n- 项目乙')])
    setup_history(bridge, monkeypatch, entries)
    assert bridge.on_message(message('/历史', ident='om_history'))
    assert bridge.process_one()
    row = bridge.store.db.execute('SELECT * FROM outbox ORDER BY id DESC LIMIT 1').fetchone()
    card = bridge.store.get('outgoing_card:' + str(row['id']))
    assert card['header']['title']['content'] == '对话历史 · 训练监控'
    blocks = [node for node in nodes(card) if node.get('tag') == 'column' and node.get('background_style')]
    assert [node['background_style'] for node in blocks] == ['blue-50', 'grey-50'] * 3
    assert [label(node['elements'][0]) for node in blocks] == ['👤 你 · 消息', '🤖 Codex · 回复'] * 3
    assert [label(node['elements'][1]) for node in blocks][::2] == [entry[1] for entry in entries[4::2]]
    assert all(node['elements'][1]['tag'] == 'markdown' for node in blocks[1::2])
    assert '← 更早对话' in [label(node) for node in buttons(card)]


def test_history_paging_is_stable_and_bound_to_its_session(bridge, monkeypatch):
    entries = [(role, f'{role}-{index}') for index in range(5) for role in ('user', 'assistant')]
    setup_history(bridge, monkeypatch, entries)
    recent = bridge.history.open()
    older = next(button for button in buttons(recent) if label(button) == '← 更早对话')
    entries.extend([('user', '后来的新问题'), ('assistant', '后来的新答案')])
    command = bridge.cards.command(button_value(older))
    card = bridge.history.dispatch(command)
    rendered = '\n'.join(label(node) for node in nodes(card))
    assert 'user-0' in rendered and 'assistant-1' in rendered and '后来的' not in rendered
    assert '较新对话 →' in [label(button) for button in buttons(card)]
    bridge.engine.choose(SECOND)
    with pytest.raises(ValueError, match='会话已切换'):
        bridge.cards.command(button_value(older))
    with pytest.raises(ValueError, match='会话已切换'):
        bridge.history.dispatch(command)


def test_long_reply_can_be_read_in_full_without_wechat_text_splitting(bridge, monkeypatch):
    answer = ('长回复逐字保留。' * 1200) + '\n\n最后一段不可丢失。'
    setup_history(bridge, monkeypatch, [('user', '请给出完整回复'), ('assistant', answer)])
    card = bridge.history.open()
    full = next(button for button in buttons(card) if label(button) == '查看完整回复')
    command = bridge.cards.command(button_value(full))
    chunks = []
    while True:
        detail = bridge.history.dispatch(command)
        panel = next(node for node in nodes(detail) if node.get('background_style') == 'grey-50')
        chunks.append(label(panel['elements'][1]))
        assert len(json.dumps(detail, ensure_ascii=False).encode()) < 20000
        next_button = next((button for button in buttons(detail) if label(button) == '下一段 →'), None)
        if next_button is None:
            back = next(button for button in buttons(detail) if label(button) == '返回对话历史')
            assert bridge.history.dispatch(bridge.cards.command(button_value(back)))['schema'] == '2.0'
            break
        command = bridge.cards.command(button_value(next_button))
    assert ''.join(chunks) == answer


def test_history_card_retries_preserve_roles_content_and_callbacks(bridge, monkeypatch):
    setup_history(bridge, monkeypatch, [('user', '原问题'), ('assistant', '原答案')])
    # Clear the binding greeting; this test sends only the prepared history card.
    with bridge.store.lock, bridge.store.db:
        bridge.store.db.execute('UPDATE outbox SET sent=1')
    card = bridge.history.open()
    bridge.store.enqueue_card('ou_owner', '对话历史', card)
    attempts = []
    def fail(chat, card, ident):
        attempts.append((chat, card, ident))
        raise RuntimeError('retry')
    assert bridge.send_one(fail)
    with bridge.store.lock, bridge.store.db:
        bridge.store.db.execute('UPDATE outbox SET next_try=0')
    assert bridge.send_one(lambda *args: attempts.append(args))
    assert attempts[0] == attempts[1] and attempts[0][1] == card


def test_empty_history_and_user_role_labels_in_content(bridge, monkeypatch):
    setup_history(bridge, monkeypatch, [])
    assert '这个会话还没有可显示的对话。' in [label(node) for node in nodes(bridge.history.open())]
    monkeypatch.setattr(bridge.engine.catalog, 'history', lambda *args, **kwargs: [('user', 'Codex：这是我引用的话\n你：不是第二个人')])
    card = bridge.history.open()
    blocks = [node for node in nodes(card) if node.get('background_style') == 'blue-50']
    assert len(blocks) == 1 and label(blocks[0]['elements'][0]) == '👤 你 · 消息'
    assert 'Codex：这是我引用的话' in label(blocks[0]['elements'][1])


def test_history_normalization_retains_links_and_code():
    source = '**结论**\\\n&#x20;[文档](https://example.com)\n* 项目\n```python\npath = "C:\\"\nvalue = "&#x20;"\n```'
    result = readable_text(source)
    assert '**结论**\n [文档](https://example.com)\n- 项目' in result
    assert 'path = "C:\\"\nvalue = "&#x20;"' in result


def test_all_paginated_history_preserves_order_and_filters_scaffolding(bridge, monkeypatch):
    with sqlite3.connect(bridge.engine.catalog.path) as db:
        db.execute("ALTER TABLE threads ADD COLUMN history_mode TEXT DEFAULT 'legacy'")
        db.execute("UPDATE threads SET history_mode='paginated' WHERE id=?", (FIRST,))
    calls = []
    class RPC:
        def __init__(self, *args, **kwargs): pass
        def call(self, method, params):
            calls.append((method, params))
            assert method == 'thread/turns/list' and params['limit'] == 100
            if not params.get('cursor'):
                return {'data': [{'items': [
                    {'type': 'userMessage', 'content': [{'type': 'text', 'text': '<environment_context>隐藏'}]},
                    {'type': 'userMessage', 'content': [{'type': 'text', 'text': '较新问题'}]},
                    {'type': 'agentMessage', 'phase': 'final_answer', 'text': '较新回复'}]}], 'nextCursor': 'older'}
            assert params['cursor'] == 'older'
            return {'data': [{'items': [
                {'type': 'userMessage', 'content': [{'type': 'text', 'text': '较早问题'}]},
                {'type': 'agentMessage', 'phase': 'commentary', 'text': '隐藏过程'},
                {'type': 'agentMessage', 'phase': 'final_answer', 'text': '较早回复'}]}]}
        def close(self): pass
    monkeypatch.setattr('codex_rpc.CodexRPC', RPC)
    assert bridge.engine.catalog.history(FIRST, limit=None) == [
        ('user', '较早问题'), ('assistant', '较早回复'), ('user', '较新问题'), ('assistant', '较新回复')]
    assert len(calls) == 2

import json
import os
import subprocess
import sys
import time
from pathlib import Path

import pytest

import session_unlock as unlock
from test_feishu import bridge, bind, button_value, callback, FIRST, SECOND


def start_holder(path, *, home, home_env=None):
    code = ('import fcntl,sys,time; f=open(sys.argv[1],"a+"); '
            'fcntl.flock(f,fcntl.LOCK_EX); print("ready",flush=True); time.sleep(60)')
    process = subprocess.Popen([sys.executable, '-c', code, str(path)], stdout=subprocess.PIPE,
                               text=True, env=dict(os.environ, CODEX_HOME=str(home_env or home)))
    assert process.stdout.readline().strip() == 'ready'
    return process


def test_real_kernel_locks_and_unheld_files_are_distinguished(tmp_path):
    directory = tmp_path / 'thread-writer-locks'
    directory.mkdir()
    path = directory / (FIRST + '.lock')
    (directory / (SECOND + '.lock')).touch()
    (directory / '.coordination.lock').touch()
    process = start_holder(path, home=tmp_path)
    try:
        rows = unlock.inventory(tmp_path)
        assert len(rows) == 2
        assert rows[0]['locked'] and rows[0]['holders'] == [process.pid]
        assert not rows[1]['locked'] and rows[1]['holders'] == []
    finally:
        process.terminate()
        process.wait(timeout=3)
    assert all(not row['locked'] for row in unlock.inventory(tmp_path))
    assert path.exists() and (directory / '.coordination.lock').exists()


def test_inventory_tolerates_lock_removed_during_scan(tmp_path, monkeypatch):
    directory = tmp_path / 'thread-writer-locks'
    directory.mkdir()
    path = directory / (FIRST + '.lock')
    path.touch()
    original_open = unlock.os.open

    def remove_before_open(target, flags):
        if Path(target) == path:
            path.unlink()
        return original_open(target, flags)

    monkeypatch.setattr(unlock.os, 'open', remove_before_open)
    assert unlock.inventory(tmp_path) == []


def test_unknown_holder_is_never_signalled(tmp_path):
    directory = tmp_path / 'thread-writer-locks'
    directory.mkdir()
    process = start_holder(directory / (FIRST + '.lock'), home=tmp_path)
    try:
        result = unlock.unlock_all(tmp_path, tmp_path / 'receipt.json')
        assert result['status'] == 'failed' and not result['all_locks_released']
        assert process.poll() is None and result['signalled'] == []
        assert '不是这个 CODEX_HOME' in result['errors'][0]
    finally:
        process.terminate()
        process.wait(timeout=3)


def test_unlock_verifies_process_exit_and_preserves_files(tmp_path, monkeypatch):
    directory = tmp_path / 'thread-writer-locks'
    directory.mkdir()
    path = directory / (FIRST + '.lock')
    process = start_holder(path, home=tmp_path)
    fields = Path(f'/proc/{process.pid}/stat').read_text().rsplit(')', 1)[1].split()
    info = path.stat()
    identity = {'pid': process.pid, 'start': fields[19], 'locks': [
        {'path': str(path), 'dev': info.st_dev, 'inode': info.st_ino}]}
    # Only the app-server identity is simulated; kernel ownership, pidfd TERM,
    # final FLOCK probe and original-process exit are exercised on a real child.
    monkeypatch.setattr(unlock, 'process_identity', lambda pid, home: identity)
    try:
        result = unlock.unlock_all(tmp_path, tmp_path / 'receipt.json')
        process.wait(timeout=3)
        assert result['status'] == 'complete' and result['all_locks_released']
        assert result['exited'][str(process.pid)]
        assert not result['after'][0]['locked'] and path.exists()
        assert json.loads((tmp_path / 'receipt.json').read_text())['status'] == 'complete'
        assert (tmp_path / 'receipt.json').stat().st_mode & 0o777 == 0o600
    finally:
        if process.poll() is None:
            process.terminate()
            process.wait(timeout=3)


def test_pid_identity_change_prevents_signal(monkeypatch):
    signals, closes = [], []
    monkeypatch.setattr(unlock.os, 'pidfd_open', lambda pid: 42, raising=False)
    monkeypatch.setattr(unlock.os, 'close', closes.append)
    monkeypatch.setattr(unlock.signal, 'pidfd_send_signal', lambda *args: signals.append(args), raising=False)
    monkeypatch.setattr(unlock, 'process_identity', lambda *args: {'pid': 10, 'start': 'changed', 'locks': [1]})
    with pytest.raises(ValueError, match='身份或锁已变化'):
        unlock.signal_holder({'pid': 10, 'start': 'original', 'locks': [1]}, '/home/target')
    assert signals == [] and closes == [42]


def test_lock_symlink_is_rejected(tmp_path):
    directory = tmp_path / 'thread-writer-locks'
    directory.mkdir()
    target = tmp_path / 'outside.lock'
    target.touch()
    (directory / (FIRST + '.lock')).symlink_to(target)
    result = unlock.unlock_all(tmp_path, tmp_path / 'receipt.json')
    assert result['status'] == 'failed' and result['signalled'] == []


def test_concurrent_operation_is_not_started(tmp_path):
    import fcntl
    with (tmp_path / 'session-unlock-operation.lock').open('a+') as guard:
        fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
        result = unlock.unlock_all(tmp_path, tmp_path / 'receipt.json')
        assert result['status'] == 'busy' and not result['all_locks_released']


def test_global_unlock_button_is_owner_scoped_and_independent_of_selection(bridge, monkeypatch):
    bind(bridge)
    card = bridge.cards.render('操作')
    button = next(column['elements'][0] for row in card['body']['elements'] if row['tag'] == 'column_set'
                  for column in row['columns'] if column['elements'][0]['text']['content'] == '一键解锁全部会话')
    assert button['type'] == 'danger' and 'confirm' not in button
    calls = []
    def release(home, receipt):
        calls.append((home, receipt))
        return {'status': 'complete', 'all_locks_released': True, 'before': [{'locked': True}],
                'after': [], 'errors': []}
    monkeypatch.setattr('feishu_bot.unlock_all', release)
    bridge.engine.choose(SECOND)
    assert bridge.on_card(callback(button_value(button), owner='stranger'))['toast']['type'] == 'error'
    assert bridge.on_card(callback(button_value(button), chat='other'))['toast']['type'] == 'error'
    assert bridge.on_card(callback(button_value(button)))['toast']['type'] == 'success'
    assert bridge.on_card(callback(button_value(button)))['toast']['type'] == 'success'
    assert bridge.process_one() and not bridge.process_one()
    assert calls == [(bridge.engine.catalog.home, bridge.store.directory / 'session-unlock-receipt.json')]


def test_unlock_command_is_not_confused_with_task_text(bridge, monkeypatch):
    calls = []
    monkeypatch.setattr(bridge.engine, 'submit', lambda text: calls.append(text) or 'submitted')
    assert bridge.engine.dispatch('请解锁全部会话以后再执行') == 'submitted'
    assert bridge.engine.dispatch('说 解锁全部会话') == 'submitted'
    assert calls == ['请解锁全部会话以后再执行', '解锁全部会话']

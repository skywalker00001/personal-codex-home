"""Private state and read-only discovery of this project's Codex conversations."""
from __future__ import annotations

import fcntl
import json
import os
import re
import secrets
import sqlite3
import threading
import time
from pathlib import Path


def private_json(path: Path, data: dict) -> None:
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    temp = path.with_name(path.name + "." + secrets.token_hex(6))
    fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as out:
        json.dump(data, out, ensure_ascii=False)
        out.flush()
        os.fsync(out.fileno())
    os.replace(temp, path)


def split_text(text: str, limit: int = 2700) -> list[str]:
    """Split on paragraph boundaries when possible, staying below Weixin's byte limit."""
    chunks = []
    start = 0
    while start < len(text):
        end, size = start, 0
        while end < len(text):
            width = len(text[end].encode("utf-8"))
            if size + width > limit:
                break
            size += width
            end += 1
        if end == start:
            raise ValueError("单个字符超过消息字节限制")
        if end < len(text):
            halfway = start + (end - start) // 2
            for delimiter in ("\n\n", "\n", "。", "；"):
                boundary = text.rfind(delimiter, halfway, end)
                if boundary >= 0:
                    end = boundary + len(delimiter)
                    break
        chunks.append(text[start:end])
        start = end
    return chunks


class Store:
    def __init__(self, directory: Path):
        directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        os.chmod(directory, 0o700)
        self.directory = directory
        self.lock = threading.RLock()
        self.db = sqlite3.connect(str(directory / "bridge.sqlite"), check_same_thread=False)
        os.chmod(directory / "bridge.sqlite", 0o600)
        self.db.row_factory = sqlite3.Row
        self.db.executescript("""
            PRAGMA journal_mode=WAL;
            PRAGMA synchronous=FULL;
            CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS inbox (
                id TEXT PRIMARY KEY, body TEXT NOT NULL, state TEXT NOT NULL DEFAULT 'pending',
                created REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS outbox (
                id INTEGER PRIMARY KEY, client_id TEXT UNIQUE NOT NULL, peer TEXT NOT NULL,
                text TEXT NOT NULL, created REAL NOT NULL, sent REAL, attempts INTEGER DEFAULT 0,
                next_try REAL DEFAULT 0, error TEXT);
        """)
        self.db.commit()

    def get(self, key, default=None):
        with self.lock:
            row = self.db.execute("SELECT value FROM kv WHERE key=?", (key,)).fetchone()
        return json.loads(row[0]) if row else default

    def put(self, key, value):
        with self.lock, self.db:
            self.db.execute("INSERT OR REPLACE INTO kv VALUES (?,?)", (key, json.dumps(value, ensure_ascii=False)))


    def enqueue(self, peer: str, text: str):
        chunks = split_text(text)
        with self.lock, self.db:
            for i, chunk in enumerate(chunks):
                prefix = f"({i + 1}/{len(chunks)}) " if len(chunks) > 1 else ""
                self.db.execute("INSERT INTO outbox(client_id,peer,text,created) VALUES (?,?,?,?)",
                                ("houyi-" + secrets.token_hex(16), peer, prefix + chunk, time.time()))

    def enqueue_card(self, peer: str, summary: str, card: dict):
        """Persist a structured card and its outbox entry atomically, without text splitting."""
        with self.lock, self.db:
            cursor = self.db.execute("INSERT INTO outbox(client_id,peer,text,created) VALUES (?,?,?,?)",
                                     ("houyi-" + secrets.token_hex(16), peer, summary, time.time()))
            self.db.execute("INSERT INTO kv VALUES (?,?)",
                            ('outgoing_card:' + str(cursor.lastrowid), json.dumps(card, ensure_ascii=False)))

    def ingest(self, messages: list[dict], cursor: str, owner: str):
        """Commit the receive cursor together with messages, before executing anything."""
        with self.lock, self.db:
            for msg in messages:
                if msg.get("from_user_id") != owner or msg.get("group_id") or msg.get("message_type") != 1:
                    continue
                raw_id = msg.get("message_id") or msg.get("client_id")
                if raw_id is None:
                    continue  # No stable id: cannot deduplicate safely.
                key = f"{owner}:{raw_id}"
                self.db.execute("INSERT OR IGNORE INTO inbox(id,body,created) VALUES (?,?,?)",
                                (key, json.dumps(msg, ensure_ascii=False), time.time()))
                if msg.get("context_token"):
                    self.db.execute("INSERT OR REPLACE INTO kv VALUES (?,?)",
                                    ("context:" + owner, json.dumps(msg["context_token"])))
                    self.db.execute("UPDATE outbox SET next_try=0 WHERE sent IS NULL AND peer=?", (owner,))
            if cursor:
                self.db.execute("INSERT OR REPLACE INTO kv VALUES ('cursor',?)", (json.dumps(cursor),))

    def claim(self):
        with self.lock, self.db:
            row = self.db.execute("SELECT * FROM inbox WHERE state='pending' ORDER BY created,id LIMIT 1").fetchone()
            if row:
                self.db.execute("UPDATE inbox SET state='processing' WHERE id=?", (row["id"],))
                return dict(row)

    def finish(self, message_id):
        with self.lock, self.db:
            self.db.execute("UPDATE inbox SET state='done' WHERE id=?", (message_id,))

    def recover(self, owner):
        with self.lock, self.db:
            count = self.db.execute("SELECT count(*) FROM inbox WHERE state='processing'").fetchone()[0]
            self.db.execute("UPDATE inbox SET state='uncertain' WHERE state='processing'")
        tasks = self.get("tasks", {})
        active = [k for k, v in tasks.items() if v.get("status") in {"starting", "running", "waiting"}]
        for key in active:
            tasks[key]["status"] = "服务重启，需检查历史确认结果"
        self.put("tasks", tasks)
        if count or active:
            self.enqueue(owner, "桥接服务已重启。此前未确认完成的指令不会自动重跑；请发“进度”或“历史”核对后再继续。")

    def next_outgoing(self):
        with self.lock:
            # Preserve message order, including multipart answers, across retries.
            row = self.db.execute("SELECT * FROM outbox WHERE sent IS NULL ORDER BY id LIMIT 1").fetchone()
            return dict(row) if row and row["next_try"] <= time.time() else None

    def sent(self, ident):
        with self.lock, self.db:
            self.db.execute("UPDATE outbox SET sent=?,error=NULL WHERE id=?", (time.time(), ident))

    def failed(self, ident, attempts, error):
        with self.lock, self.db:
            self.db.execute("UPDATE outbox SET attempts=?,next_try=?,error=? WHERE id=?",
                            (attempts, time.time() + min(300, 2 ** min(attempts, 8)), error[:250], ident))


class Catalog:
    def __init__(self, home: Path, project: Path):
        self.home, self.project = home.resolve(), project.resolve()
        candidates = sorted(home.glob("state_*.sqlite"), key=lambda p: int(p.stem.split("_")[-1]))
        if not candidates:
            raise RuntimeError("找不到所选 CODEX_HOME 的会话索引")
        self.path = candidates[-1]

    def scoped(self, cwd):
        if not cwd or not Path(cwd).is_absolute():
            return False
        try:
            Path(cwd).resolve().relative_to(self.project)
            return True
        except (ValueError, OSError):
            return False

    def rows(self, archived=False):
        with sqlite3.connect(self.path.as_uri() + "?mode=ro", uri=True) as db:
            db.row_factory = sqlite3.Row
            rows = [dict(r) for r in db.execute("SELECT * FROM threads WHERE archived=? ORDER BY updated_at DESC", (int(archived),))]
        return [r for r in rows if self.scoped(r.get("cwd")) and
                not str(r.get("source", "")).lower().startswith(('subagent', '{"subagent')) and
                r.get("agent_path") in (None, "", "/root")]

    def get(self, ident):
        if not re.fullmatch(r"[0-9a-f-]{36}", ident):
            raise ValueError("会话 ID 无效")
        with sqlite3.connect(self.path.as_uri() + "?mode=ro", uri=True) as db:
            db.row_factory = sqlite3.Row
            row = db.execute("SELECT * FROM threads WHERE id=?", (ident,)).fetchone()
        if not row or not self.scoped(row["cwd"]):
            raise ValueError("会话不存在或不属于 Houyi 工作目录")
        return dict(row)

    def locked(self, ident):
        if not re.fullmatch(r"[0-9a-f-]{36}", ident):
            raise ValueError("会话 ID 无效")
        path = self.home / "thread-writer-locks" / (ident + ".lock")
        try:
            with path.open("r") as f:
                try:
                    fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    fcntl.flock(f, fcntl.LOCK_UN)
                    return False
                except BlockingIOError:
                    return True
        except FileNotFoundError:
            return False

    def history(self, ident, limit=8):
        row = self.get(ident)
        if row.get("history_mode") == "paginated":
            # Forks/new clients can store items in Codex's paginated DB, not rollout JSONL.
            # These are read-only protocol calls and never resume/acquire the thread.
            from codex_rpc import CodexRPC
            rpc = CodexRPC(self.home, self.project, binary=os.environ.get("CODEX_BRIDGE_BIN", "codex"))
            try:
                turns, cursor, seen = [], None, set()
                while True:
                    params = {"threadId": ident, "limit": 100 if limit is None else limit,
                              "sortDirection": "desc", "itemsView": "full"}
                    if cursor:
                        params['cursor'] = cursor
                    result = rpc.call("thread/turns/list", params)
                    turns.extend(result.get('data', []))
                    cursor = result.get('nextCursor')
                    if limit is not None or not cursor:
                        break
                    if cursor in seen:
                        raise ValueError('历史分页异常，请稍后重试。')
                    seen.add(cursor)
            finally:
                rpc.close()
            messages = []
            for turn in reversed(turns):
                for item in turn.get("items", []):
                    if item.get("type") == "userMessage":
                        value = "\n".join(c.get("text", "") for c in item.get("content", []) if c.get("type") == "text")
                        role = "user"
                    elif item.get("type") == "agentMessage" and item.get("phase") != "commentary":
                        value, role = item.get("text", ""), "assistant"
                    else:
                        continue
                    if role == 'user' and value.startswith(("<environment_context>", "# AGENTS.md", "<permissions instructions>", "<external_codex_apps_open_page>")):
                        continue
                    if value:
                        messages.append((role, value))
            return messages if limit is None else messages[-limit:]
        path = Path(row["rollout_path"]).resolve()
        path.relative_to(self.home)  # Never follow a catalog pointer outside this Codex Home.
        if not path.is_file():
            raise ValueError("会话记录文件暂不可用")
        from collections import deque
        messages = deque(maxlen=limit)
        with path.open() as f:
            for line in f:
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if record.get("type") != "response_item":
                    continue
                p = record.get("payload", {})
                if p.get("type") != "message" or p.get("role") not in {"user", "assistant"}:
                    continue
                if p.get("role") == "assistant" and p.get("phase") == "commentary":
                    continue
                text = "\n".join(c.get("text", "") for c in p.get("content", []) if c.get("type") in {"input_text", "output_text"})
                # Hide environment/system scaffolding recorded as user messages.
                if text.startswith(("<environment_context>", "# AGENTS.md", "<permissions instructions>", "<external_codex_apps_open_page>")):
                    continue
                if text:
                    messages.append((p["role"], text))
        return list(messages)

"""Per-thread model and permission choices for the authenticated Feishu owner."""
from __future__ import annotations

from chat_engine import Engine
from codex_runtime import model_catalog, model_settings


PERMISSIONS = {
    'read-only': {'label': '只读', 'approval': 'never', 'policy': {'type': 'readOnly', 'networkAccess': False}},
    'workspace-write': {'label': '工作区写入', 'approval': 'on-request', 'policy': {'type': 'workspaceWrite', 'networkAccess': False}},
    'danger-full-access': {'label': '完全访问（免审批）', 'approval': 'never', 'policy': {'type': 'dangerFullAccess'}},
}


def available_permissions(rpc):
    requirements = rpc.call('configRequirements/read', {}).get('requirements') or {}
    if requirements.get('allowedPermissionProfiles') is not None:
        raise ValueError('管理员配置了专用权限配置，当前菜单暂不能覆盖。')
    modes = requirements.get('allowedSandboxModes')
    approvals = requirements.get('allowedApprovalPolicies')
    return {mode: profile for mode, profile in PERMISSIONS.items()
            if (modes is None or mode in modes) and (approvals is None or profile['approval'] in approvals)}


class SettingsEngine(Engine):
    def preferences(self, ident):
        return self.store.get('feishu_thread_settings', {}).get(ident, {})

    def save_preferences(self, row, changes):
        with self.lock:
            active = self.jobs.get(row['id'])
            if active and not active['done'].is_set():
                raise ValueError('当前任务仍在运行，请完成后再修改模型或权限。')
            settings = self.store.get('feishu_thread_settings', {})
            settings[row['id']] = {**settings.get(row['id'], {}), **changes}
            self.store.put('feishu_thread_settings', settings)
        return '已保存到当前飞书会话，从下一轮任务生效。\n' + self.current()

    def with_runtime(self, row, callback):
        rpc = self.rpc_factory(self.catalog.home, row['cwd'], binary=self.binary)
        try:
            return callback(rpc)
        finally:
            rpc.close()

    def _dispatch(self, text):
        command = text.strip()
        if command not in {'飞书模型列表', '飞书强度列表', '飞书权限列表'} and not command.startswith(('飞书选模型 ', '飞书选强度 ', '飞书选权限 ')):
            return super()._dispatch(text)
        row = self.selected()
        if command == '飞书模型列表' or command.startswith('飞书选模型 '):
            models = self.with_runtime(row, model_catalog)
            if command == '飞书模型列表':
                self.store.put('feishu_model_menu', {'thread': row['id'], 'models': models})
                return '选择模型 · 当前会话\n点击模型名称选择，从下一轮任务生效。\n' + '\n'.join(
                    model.get('displayName') or model['model'] for model in models)
            model = command[len('飞书选模型 '):]
            if model not in {item['model'] for item in models}:
                raise ValueError('这个模型不在当前账号可用列表中，请重新选择。')
            changes = {'model': model}
            selected_model = next(item for item in models if item['model'] == model)
            supported = {item['reasoningEffort'] for item in selected_model.get('supportedReasoningEfforts', [])}
            previous_effort = self.preferences(row['id']).get('reasoning_effort')
            if previous_effort and previous_effort not in supported:
                changes['reasoning_effort'] = selected_model.get('defaultReasoningEffort')
            return self.save_preferences(row, changes)
        if command == '飞书强度列表' or command.startswith('飞书选强度 '):
            def choices(rpc):
                settings = self.runtime_settings(rpc, row)
                model = next(item for item in model_catalog(rpc) if item['model'] == settings['model'])
                return settings, [item['reasoningEffort'] for item in model.get('supportedReasoningEfforts', [])]
            settings, efforts = self.with_runtime(row, choices)
            if command == '飞书强度列表':
                self.store.put('feishu_effort_menu', {'thread': row['id'], 'model': settings['model'],
                                                     'efforts': efforts, 'current': settings['effort']})
                return ('选择推理强度 · 当前会话\n模型：' + settings['model'] + '\n当前强度：' +
                        (settings['effort'] or '默认') + '\n从下一轮任务生效。' +
                        ('\n此模型没有可调整的推理强度。' if not efforts else ''))
            effort = command[len('飞书选强度 '):]
            menu = self.store.get('feishu_effort_menu', {})
            if menu.get('thread') != row['id'] or menu.get('model') != settings['model']:
                raise ValueError('模型或会话已变化，请重新打开推理强度菜单。')
            if effort not in efforts:
                raise ValueError('当前模型不支持这个推理强度，请重新选择。')
            return self.save_preferences(row, {'reasoning_effort': effort})
        profiles = self.with_runtime(row, available_permissions)
        if command == '飞书权限列表':
            self.store.put('feishu_permission_menu', {'thread': row['id'], 'modes': list(profiles)})
            return ('选择权限 · 当前会话\n从下一轮任务生效，仍受机器系统权限和管理员限制。\n'
                    '只读：文件只读，网络受限，不申请写入升级。\n'
                    '工作区写入：可修改会话目录及临时目录，网络受限，越界需审批。\n'
                    '完全访问：取消 Codex 文件和网络沙箱，免审批。')
        mode = command[len('飞书选权限 '):]
        if mode not in profiles:
            raise ValueError('该权限模式不被当前管理员配置允许，请重新选择。')
        return self.save_preferences(row, {'permission': mode})

    def runtime_settings(self, rpc, row):
        preferences = self.preferences(row['id'])
        settings = model_settings(rpc, {**row, **{key: preferences[key] for key in ('model', 'reasoning_effort') if key in preferences}})
        if preferences.get('model') and preferences['model'] != settings['model']:
            raise ValueError('已选择的模型不再适用于当前账号，请重新选择模型。')
        mode = preferences.get('permission')
        if row['id'].startswith('draft:') and not mode:
            profiles = available_permissions(rpc)
            mode = 'danger-full-access'
            if mode not in profiles:
                raise ValueError('管理员配置不允许 Full access，无法按默认权限创建飞书会话。')
        if mode:
            profiles = available_permissions(rpc)
            if mode not in profiles:
                raise ValueError('已选择的权限模式不再被管理员配置允许，请重新选择。')
            profile = profiles[mode]
            policy = dict(profile['policy'])
            if mode == 'workspace-write':
                policy['writableRoots'] = [row['cwd']]
            settings['threadOverrides'] = {'sandbox': mode, 'approvalPolicy': profile['approval']}
            settings['turnOverrides'] = {'sandboxPolicy': policy, 'approvalPolicy': profile['approval']}
        return settings

    def thread_ready(self, row, result, settings):
        ident = result['thread']['id']
        preferences = self.store.get('feishu_thread_settings', {})
        if ident != row['id'] and row['id'] in preferences:
            preferences[ident] = dict(preferences[row['id']])
            if row['id'].startswith('draft:'):
                preferences.pop(row['id'])
            self.store.put('feishu_thread_settings', preferences)
        elif row['id'].startswith('draft:'):
            preferences[ident] = {'permission': 'danger-full-access'}
            self.store.put('feishu_thread_settings', preferences)
        effective = self.store.get('feishu_effective_settings', {})
        effective[ident] = {'model': result.get('model') or settings['model'],
                            'effort': result.get('reasoningEffort') or settings['effort'],
                            'sandbox': result.get('sandbox'), 'approval': result.get('approvalPolicy')}
        self.store.put('feishu_effective_settings', effective)

# Clawbot Feishu Codex

从 [部署指南](FEISHU_CODEX_DEPLOY.md) 开始。

本包只有必要源码；请使用自己的飞书应用与 Codex 账号。

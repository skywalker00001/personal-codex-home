import json
import sqlite3
import time
import threading
from pathlib import Path

import pytest

from bridge_state import Catalog
from feishu_bot import Bridge


FIRST = '11111111-1111-1111-1111-111111111111'
SECOND = '22222222-2222-2222-2222-222222222222'


@pytest.fixture
def bridge(tmp_path):
    project = tmp_path / 'houyi'
    project.mkdir()
    home = tmp_path / 'codex'
    home.mkdir()
    with sqlite3.connect(home / 'state_5.sqlite') as db:
        db.execute('CREATE TABLE threads(id TEXT PRIMARY KEY,cwd TEXT,title TEXT,updated_at INTEGER,archived INTEGER,source TEXT,agent_path TEXT)')
        db.executemany('INSERT INTO threads VALUES(?,?,?,?,?,?,?)', [
            (FIRST, str(project), '训练监控', 20, 0, 'vscode', None),
            (SECOND, str(project), '结果评估', 10, 0, 'cli', None),
        ])
    config = {'app_id': 'cli_test', 'app_secret': 'test-secret', 'pairing_code': 'pair-code', 'initial_thread': FIRST}
    return Bridge(tmp_path / 'feishu', config, Catalog(home, project))


def message(text, *, owner='ou_owner', chat='oc_private', ident='om_1', chat_type='p2p'):
    return {'event': {'sender': {'sender_type': 'user', 'sender_id': {'open_id': owner}},
                      'message': {'message_id': ident, 'chat_id': chat, 'chat_type': chat_type,
                                  'message_type': 'text', 'create_time': str(int(time.time() * 1000)),
                                  'content': json.dumps({'text': text})}}}


def bind(bridge):
    assert bridge.on_message(message('/绑定 pair-code'))
    assert bridge.process_one()


def button_value(button):
    return button['behaviors'][0]['value']


def callback(value, *, owner='ou_owner', chat='oc_private', ident='ev_click'):
    return {'header': {'event_id': ident}, 'event': {'operator': {'open_id': owner},
            'context': {'open_chat_id': chat}, 'action': {'value': value}}}


def test_owner_pairing_and_untrusted_users_never_reach_codex(bridge):
    assert not bridge.on_message(message('执行任意任务'))
    assert not bridge.on_message(message('/绑定 wrong'))
    assert not bridge.on_message(message('/绑定 pair-code', chat_type='group'))
    bind(bridge)
    saved = json.loads((bridge.directory / 'config.json').read_text())
    assert saved['owner_open_id'] == 'ou_owner' and 'pairing_code' not in saved
    assert (bridge.directory / 'config.json').stat().st_mode & 0o777 == 0o600
    assert not bridge.on_message(message('任务', owner='ou_stranger', ident='om_stranger'))
    assert not bridge.on_message(message('任务', chat_type='group', ident='om_group'))


def test_message_deduplication_and_stale_event_rejection(bridge):
    bind(bridge)
    event = message('当前', ident='om_2')
    assert bridge.on_message(event)
    assert bridge.on_message(event)
    assert bridge.process_one()
    assert not bridge.process_one()
    event['event']['message']['create_time'] = '1000'
    event['event']['message']['message_id'] = 'om_stale'
    assert not bridge.on_message(event)


def test_card_callbacks_are_scoped_and_do_not_trust_raw_commands(bridge):
    bind(bridge)
    button = bridge.cards.button('进度', '进度')
    assert bridge.on_card(callback({'command': '危险命令'}))['toast']['type'] == 'error'
    assert bridge.on_card(callback(button_value(button), owner='ou_stranger'))['toast']['type'] == 'error'
    assert bridge.on_card(callback(button_value(button), chat='oc_other'))['toast']['type'] == 'error'
    assert bridge.on_card(callback(button_value(button)))['toast']['type'] == 'success'
    assert bridge.on_card(callback(button_value(button)))['toast']['type'] == 'success'
    assert bridge.process_one() and not bridge.process_one()


def test_session_buttons_use_stable_thread_ids(bridge):
    bind(bridge)
    text = bridge.engine.dispatch('会话')
    card = bridge.cards.render(text)
    buttons = [column['elements'][0] for element in card['body']['elements'] if element['tag'] == 'column_set'
               for column in element['columns']]
    select = next(button for button in buttons if button['text']['content'] == '进入 · 结果评估')
    with sqlite3.connect(bridge.engine.catalog.path) as db:
        db.execute('UPDATE threads SET updated_at=100 WHERE id=?', (SECOND,))
    assert bridge.cards.command(button_value(select)) == '切换 ' + SECOND
    assert bridge.on_card(callback(button_value(select)))['toast']['type'] == 'success'
    bridge.process_one()
    assert bridge.store.get('selected') == SECOND
    assert card['schema'] == '2.0'


def test_stop_card_is_available_for_current_task_but_not_another_session(bridge):
    bind(bridge)
    bridge.engine.jobs[FIRST] = {'turn': 'turn-1'}
    button = bridge.cards.button('停止', '停止', target=FIRST, confirm=True)
    bridge.engine.choose(SECOND)
    with pytest.raises(ValueError, match='会话已切换'):
        bridge.cards.command(button_value(button))
    bridge.engine.choose(FIRST)
    bridge.engine.jobs[FIRST]['turn'] = 'turn-2'
    assert bridge.cards.command(button_value(button)) == '停止'


def test_outbound_retries_keep_uuid_and_card_identical(bridge):
    bind(bridge)
    sent = []
    def failure(chat, card, ident):
        sent.append((chat, card, ident))
        raise RuntimeError('not sent')
    assert bridge.send_one(failure)
    with bridge.store.lock, bridge.store.db:
        bridge.store.db.execute('UPDATE outbox SET next_try=0')
    assert bridge.send_one(lambda chat, card, ident: sent.append((chat, card, ident)))
    assert sent[0] == sent[1]
    assert not bridge.store.next_outgoing()


def test_sdk_parses_real_card_callback_and_toast_shape(bridge):
    import lark_oapi as lark
    from lark_oapi.event.callback.model.p2_card_action_trigger import P2CardActionTrigger, P2CardActionTriggerResponse
    bind(bridge)
    button = bridge.cards.button('当前', '当前')
    event = P2CardActionTrigger(callback(button_value(button)))
    result = bridge.on_card(json.loads(lark.JSON.marshal(event)))
    response = P2CardActionTriggerResponse(result)
    assert response.toast.type == 'success'


def test_expired_actions_are_rejected(bridge):
    button = bridge.cards.button('会话', '会话')
    value = button_value(button)
    actions = bridge.store.get('feishu_actions')
    actions[value['token']]['expires'] = 0
    bridge.store.put('feishu_actions', actions)
    with pytest.raises(ValueError, match='卡片已过期'):
        bridge.cards.command(value)


def test_default_card_has_only_requested_navigation(bridge):
    card = bridge.cards.render('回复内容')
    navigation = [element for element in card['body']['elements'] if element['tag'] == 'column_set']
    assert [len(row['columns']) for row in navigation] == [3, 3, 1, 3]
    buttons = [column['elements'][0] for element in card['body']['elements'] if element['tag'] == 'column_set'
               for column in element['columns']]
    assert [button['text']['content'] for button in buttons] == ['会话', '当前', '历史', '新建', '分支', '停止', '一键解锁全部会话', '选择模型', '推理强度', '权限']
    stop = buttons[5]
    assert stop['type'] == 'danger' and 'confirm' not in stop
    assert [bridge.cards.command(button_value(button)) for button in buttons[:4]] == ['会话', '当前', '历史', '新建']


class SettingsRPC:
    calls = []
    requirements = {}
    target = FIRST

    def __init__(self, home, cwd, callback=None, **kwargs):
        self.cwd, self.callback = cwd, callback
        self.proc = type('Process', (), {'poll': lambda process: None})()

    def call(self, method, params):
        self.calls.append((method, params))
        if method == 'config/read':
            return {'config': {'model': 'model-default', 'model_reasoning_effort': 'medium'}}
        if method == 'model/list':
            return {'data': [{'model': model, 'displayName': model, 'isDefault': model == 'model-default',
                              'defaultReasoningEffort': 'medium', 'supportedReasoningEfforts': [
                                  {'reasoningEffort': effort} for effort in (['medium', 'high'] if model == 'model-default' else ['medium'])]}
                             for model in ['model-default', 'model-other']]}
        if method == 'configRequirements/read':
            return {'requirements': self.requirements}
        if method.startswith('thread/'):
            return {'thread': {'id': self.target, 'cwd': self.cwd}, 'model': params['model'],
                    'sandbox': {'type': 'dangerFullAccess' if params.get('sandbox') == 'danger-full-access' else 'readOnly'},
                    'approvalPolicy': params.get('approvalPolicy'), 'reasoningEffort': 'medium'}
        if method == 'turn/start':
            self.callback({'method': 'item/completed', 'params': {'item': {
                'type': 'agentMessage', 'phase': 'final_answer', 'text': 'SETTINGS_OK'}}})
            self.callback({'method': 'turn/completed', 'params': {'turn': {'status': 'completed'}}})
            return {'turn': {'id': 'turn-1'}}
        raise AssertionError(method)

    def close(self):
        pass


@pytest.fixture
def settings_bridge(bridge, monkeypatch):
    monkeypatch.setattr(SettingsRPC, 'calls', [])
    monkeypatch.setattr(SettingsRPC, 'requirements', {})
    monkeypatch.setattr(SettingsRPC, 'target', FIRST)
    bridge.engine.rpc_factory = SettingsRPC
    return bridge


def test_model_choice_is_account_validated_and_thread_scoped(settings_bridge):
    engine = settings_bridge.engine
    text = engine.dispatch('飞书模型列表')
    card = settings_bridge.cards.render(text)
    assert 'model-other' in text
    engine.dispatch('飞书选模型 model-other')
    assert engine.preferences(FIRST)['model'] == 'model-other'
    engine.choose(SECOND)
    assert engine.preferences(SECOND) == {}
    with pytest.raises(ValueError, match='可用列表'):
        engine.dispatch('飞书选模型 unlisted-model')
    model_buttons = [column['elements'][0] for element in card['body']['elements'] if element['tag'] == 'column_set'
                     for column in element['columns'] if column['elements'][0]['text']['content'] == 'model-other']
    with pytest.raises(ValueError, match='会话已切换'):
        settings_bridge.cards.command(button_value(model_buttons[0]))


@pytest.mark.parametrize('mode,policy', [('read-only', 'readOnly'), ('workspace-write', 'workspaceWrite'),
                                      ('danger-full-access', 'dangerFullAccess')])
def test_model_and_permission_choices_reach_resume_and_turn(settings_bridge, mode, policy):
    engine = settings_bridge.engine
    engine.dispatch('飞书选模型 model-other')
    engine.dispatch('飞书选权限 ' + mode)
    engine.submit('检查设置')
    with engine.lock:
        job = next(iter(engine.jobs.values()))
    assert job['done'].wait(3)
    assert job['status'] == 'completed'
    resume = next(params for method, params in SettingsRPC.calls if method == 'thread/resume')
    turn = next(params for method, params in SettingsRPC.calls if method == 'turn/start')
    assert resume['model'] == turn['model'] == 'model-other'
    assert resume['sandbox'] == mode and turn['sandboxPolicy']['type'] == policy
    expected_approval = 'on-request' if mode == 'workspace-write' else 'never'
    assert resume['approvalPolicy'] == turn['approvalPolicy'] == expected_approval
    if mode == 'workspace-write':
        assert turn['sandboxPolicy']['writableRoots'] == [str(engine.catalog.project)]
    assert '最近运行模型：model-other' in engine.current()


def test_admin_permission_limits_are_enforced(settings_bridge, monkeypatch):
    monkeypatch.setattr(SettingsRPC, 'requirements', {'allowedSandboxModes': ['read-only'], 'allowedApprovalPolicies': ['never']})
    settings_bridge.engine.dispatch('飞书权限列表')
    assert settings_bridge.store.get('feishu_permission_menu')['modes'] == ['read-only']
    with pytest.raises(ValueError, match='不被当前管理员'):
        settings_bridge.engine.dispatch('飞书选权限 danger-full-access')
    assert settings_bridge.engine.preferences(FIRST) == {}


def test_draft_settings_follow_the_created_thread(settings_bridge):
    engine = settings_bridge.engine
    engine.dispatch('新建 设置测试')
    draft = engine.store.get('selected')
    engine.dispatch('飞书选模型 model-other')
    engine.dispatch('飞书选权限 read-only')
    engine.submit('检查设置')
    with engine.lock:
        job = next(iter(engine.jobs.values()))
    assert job['done'].wait(3) and job['status'] == 'completed'
    assert engine.preferences(FIRST) == {'model': 'model-other', 'permission': 'read-only'}
    assert engine.preferences(draft) == {}
    start = next(params for method, params in SettingsRPC.calls if method == 'thread/start')
    assert start['sandbox'] == 'read-only'


def test_full_access_choice_requires_card_confirmation(settings_bridge):
    text = settings_bridge.engine.dispatch('飞书权限列表')
    card = settings_bridge.cards.render(text)
    full = next(column['elements'][0] for element in card['body']['elements'] if element['tag'] == 'column_set'
                for column in element['columns'] if column['elements'][0]['text']['content'] == '完全访问（免审批）')
    assert '取消' in full['confirm']['text']['content']


def test_running_task_settings_are_not_changed(settings_bridge):
    import threading
    settings_bridge.engine.jobs[FIRST] = {'done': threading.Event()}
    with pytest.raises(ValueError, match='仍在运行'):
        settings_bridge.engine.dispatch('飞书选权限 danger-full-access')
    assert settings_bridge.engine.preferences(FIRST) == {}


def test_effort_choice_reaches_thread_and_turn(settings_bridge):
    engine = settings_bridge.engine
    text = engine.dispatch('飞书强度列表')
    card = settings_bridge.cards.render(text)
    buttons = [column['elements'][0] for element in card['body']['elements'] if element['tag'] == 'column_set'
               for column in element['columns']]
    high = next(button for button in buttons if button['text']['content'] == 'high')
    assert settings_bridge.cards.command(button_value(high)) == '飞书选强度 high'
    engine.dispatch('飞书选强度 high')
    # Current-session cards show effective settings only after an actual turn.
    # The chosen setting remains persisted and must reach both native RPC calls.
    assert engine.store.get('feishu_thread_settings')[FIRST]['reasoning_effort'] == 'high'
    assert '推理强度：high' not in engine.current()
    engine.submit('检查推理强度')
    with engine.lock:
        job = next(iter(engine.jobs.values()))
    assert job['done'].wait(3) and job['status'] == 'completed'
    resume = next(params for method, params in SettingsRPC.calls if method == 'thread/resume')
    turn = next(params for method, params in SettingsRPC.calls if method == 'turn/start')
    assert resume['config']['model_reasoning_effort'] == turn['effort'] == 'high'


def test_effort_menu_rejects_stale_models_and_sessions(settings_bridge):
    engine = settings_bridge.engine
    card = settings_bridge.cards.render(engine.dispatch('飞书强度列表'))
    high = next(column['elements'][0] for element in card['body']['elements'] if element['tag'] == 'column_set'
                for column in element['columns'] if column['elements'][0]['text']['content'] == 'high')
    engine.dispatch('飞书选强度 high')
    engine.dispatch('飞书选模型 model-other')
    assert engine.preferences(FIRST)['reasoning_effort'] == 'medium'
    with pytest.raises(ValueError, match='模型已变化'):
        settings_bridge.cards.command(button_value(high))
    engine.dispatch('飞书强度列表')
    with pytest.raises(ValueError, match='不支持'):
        engine.dispatch('飞书选强度 high')
    engine.choose(SECOND)
    with pytest.raises(ValueError, match='会话已切换'):
        settings_bridge.cards.command(button_value(high))


def stop_button(bridge):
    card = bridge.cards.render('回复内容')
    return next(column['elements'][0] for element in card['body']['elements'] if element['tag'] == 'column_set'
                for column in element['columns'] if column['elements'][0]['text']['content'] == '停止')


def test_stop_button_interrupts_running_turn_and_allows_new_task(settings_bridge):
    bind(settings_bridge)
    engine = settings_bridge.engine
    started = threading.Event()
    instances = []

    class RunningRPC(SettingsRPC):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            instances.append(self)

        def call(self, method, params):
            if method == 'turn/start':
                self.calls.append((method, params))
                self.callback({'method': 'turn/started', 'params': {'turn': {'id': 'running-turn'}}})
                started.set()
                return {'turn': {'id': 'running-turn'}}
            if method == 'turn/interrupt':
                self.calls.append((method, params))
                self.callback({'method': 'turn/completed', 'params': {'turn': {'status': 'interrupted'}}})
                return {}
            return super().call(method, params)

    # A menu rendered before the task starts still stops the task active at click time.
    button = stop_button(settings_bridge)
    engine.rpc_factory = RunningRPC
    engine.submit('旧任务')
    assert started.wait(3)
    with engine.lock:
        job = engine.jobs[FIRST]
    event = callback(button_value(button), ident='ev_stop')
    assert settings_bridge.on_card(event)['toast']['type'] == 'success'
    assert settings_bridge.on_card(event)['toast']['type'] == 'success'
    assert settings_bridge.process_one() and not settings_bridge.process_one()
    assert job['done'].wait(3) and job['status'] == 'interrupted'
    interrupts = [params for method, params in SettingsRPC.calls if method == 'turn/interrupt']
    assert interrupts == [{'threadId': FIRST, 'turnId': 'running-turn'}]
    engine.rpc_factory = SettingsRPC
    engine.submit('新任务')
    with engine.lock:
        new_job = engine.jobs[FIRST]
    assert new_job is not job and new_job['done'].wait(3) and new_job['status'] == 'completed'
    assert not any(method == 'turn/steer' for method, _ in SettingsRPC.calls)


def test_delayed_stop_callback_cannot_stop_a_replacement_task(bridge):
    bind(bridge)
    engine = bridge.engine
    engine.jobs[FIRST] = {'started': 1, 'done': threading.Event(), 'cancel': threading.Event()}
    event = callback(button_value(stop_button(bridge)))
    assert bridge.on_card(event)['toast']['type'] == 'success'
    replacement = {'started': 2, 'done': threading.Event(), 'cancel': threading.Event()}
    engine.jobs[FIRST] = replacement
    assert bridge.process_one()
    assert not replacement['cancel'].is_set()


def test_idle_and_untrusted_stop_clicks_cannot_cancel_new_tasks(bridge):
    bind(bridge)
    button = stop_button(bridge)
    value = button_value(button)
    assert bridge.on_card(callback(value, owner='ou_stranger'))['toast']['type'] == 'error'
    assert bridge.on_card(callback(value, chat='oc_other'))['toast']['type'] == 'error'
    assert not bridge.process_one()
    assert bridge.on_card(callback(value, ident='ev_idle_stop'))['toast']['type'] == 'success'
    job = {'started': 1, 'done': threading.Event(), 'cancel': threading.Event()}
    bridge.engine.jobs[FIRST] = job
    assert bridge.process_one()
    assert not job['cancel'].is_set()


def test_stop_during_startup_cancels_without_starting_a_turn(settings_bridge):
    bind(settings_bridge)
    ready, release = threading.Event(), threading.Event()

    class StartingRPC(SettingsRPC):
        def call(self, method, params):
            if method == 'thread/resume':
                ready.set()
                assert release.wait(3)
            return super().call(method, params)

    engine = settings_bridge.engine
    engine.rpc_factory = StartingRPC
    engine.submit('正在接续的任务')
    assert ready.wait(3)
    with engine.lock:
        job = engine.jobs[FIRST]
    assert settings_bridge.on_card(callback(button_value(stop_button(settings_bridge))))['toast']['type'] == 'success'
    assert settings_bridge.process_one()
    assert '正在中断' in engine.submit('新的任务')
    release.set()
    assert job['done'].wait(3) and job['status'] == 'interrupted'
    assert not any(method == 'turn/start' for method, _ in SettingsRPC.calls)

"""Resolve the installed Codex runtime and account-compatible model settings."""
from __future__ import annotations

import json
import os
import platform
import shutil
from pathlib import Path


def resolve_binary(binary="codex", extension_roots=None):
    if binary != "codex":
        resolved = shutil.which(binary)
        if not resolved:
            raise RuntimeError("配置的 Codex 程序不存在，请检查 CODEX_BRIDGE_BIN")
        return resolved
    roots = extension_roots if extension_roots is not None else [
        Path.home() / ".vscode-server" / "extensions",
        Path.home() / ".vscode" / "extensions",
    ]
    machine = {"x86_64": "x86_64", "aarch64": "aarch64"}.get(platform.machine())
    target = f"{platform.system().lower()}-{machine}"
    for root in roots:
        try:
            installed = json.loads((Path(root) / "extensions.json").read_text())
        except (OSError, ValueError):
            continue
        for extension in installed:
            if extension.get("identifier", {}).get("id") != "openai.chatgpt":
                continue
            location = extension.get("location", {})
            directory = location.get("fsPath") or location.get("path")
            if not directory:
                continue
            candidate = Path(directory) / "bin" / target / "codex"
            if candidate.is_file() and os.access(candidate, os.X_OK):
                return str(candidate)
    resolved = shutil.which("codex")
    if not resolved:
        raise RuntimeError("未找到 Codex，请安装 Codex 扩展或设置 CODEX_BRIDGE_BIN")
    return resolved


def model_catalog(rpc):
    models = []
    cursor = None
    seen = set()
    while True:
        params = {"limit": 100, "includeHidden": False}
        if cursor:
            params["cursor"] = cursor
        page = rpc.call("model/list", params)
        models.extend(page.get("data", []))
        cursor = page.get("nextCursor")
        if not cursor:
            break
        if cursor in seen:
            raise RuntimeError("Codex 模型列表分页异常，请稍后重试")
        seen.add(cursor)
    return models


def model_settings(rpc, row):
    config = rpc.call("config/read", {"includeLayers": False}).get("config", {})
    models = model_catalog(rpc)
    available = {model["model"]: model for model in models if model.get("model")}
    if not available:
        raise RuntimeError("当前 Codex 账号没有可用模型，请检查登录状态")
    preferred = row.get("model")
    configured = config.get("model")
    model = available.get(preferred) or available.get(configured)
    if not model:
        model = next((item for item in available.values() if item.get("isDefault")), next(iter(available.values())))
    effort = row.get("reasoning_effort") or config.get("model_reasoning_effort")
    supported = {item.get("reasoningEffort") for item in model.get("supportedReasoningEfforts", [])}
    if effort not in supported:
        effort = model.get("defaultReasoningEffort")
    return {"model": model["model"], "modelProvider": config.get("model_provider") or "openai",
            "effort": effort, "previousModel": preferred if preferred and preferred != model["model"] else None}

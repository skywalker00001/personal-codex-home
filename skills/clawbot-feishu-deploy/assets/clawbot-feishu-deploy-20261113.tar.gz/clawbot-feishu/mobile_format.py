"""Render Codex text for a narrow, plain-text Weixin chat bubble.

The source answer stays in Codex history.  Callers may also retain the unmodified
answer for a one-shot `原文` reply when paths or Markdown cannot be shown well.
"""
from __future__ import annotations

import re

MOBILE_STYLE = (
    "【微信手机阅读偏好：仅调整本轮答复的排版，不改变用户的任务】"
    "先用一两句说清结果；多项进度逐项短行写出状态、步数、checkpoint 和机器，"
    "不要用 Markdown 表格或大段标题。关键数字、结论、风险与用户要执行的命令须保留。"
    "网页地址尽量单列；只有用户需要时才展开很长的本地文件路径。"
    "用户明确要求原文、完整代码或其他排版时，优先遵从用户的要求。"
)


def mobile_input(text: str) -> str:
    """Add a channel-specific presentation preference without rewriting the request."""
    return text + "\n\n" + MOBILE_STYLE


def _cells(line: str) -> list[str]:
    return [part.strip().replace(r"\|", "|") for part in re.split(r"(?<!\\)\|", line.strip().strip("|"))]


def _inline(text: str, omitted: list[bool]) -> str:
    def link(match):
        label, dest = match.group(1), match.group(2).strip("<>")
        if dest.startswith(("https://", "http://")):
            return dest if label == dest else label + "：" + dest
        if dest.startswith("/") and len(dest) > 85:
            omitted[0] = True
            return label
        return label + "：" + dest

    text = re.sub(r"(?<!!)\[([^\]\n]+)\]\(([^)\n]+)\)", link, text)
    text = re.sub(r"\*\*(.+?)\*\*|__(.+?)__", lambda m: m.group(1) or m.group(2), text)
    text = re.sub(r"(?<!\*)\*([^*\n]+)\*(?!\*)", r"\1", text)
    return re.sub(r"`([^`\n]+)`", r"\1", text)


def render_mobile(text: str) -> str:
    """Keep factual content and code intact; turn Markdown tables into short cards."""
    omitted = [False]
    if re.search(r"cite.*?", text):
        omitted[0] = True
        text = re.sub(r"cite.*?", "", text)
    lines = text.splitlines()
    output: list[str] = []
    i = 0
    in_code = False
    while i < len(lines):
        line = lines[i]
        if line.lstrip().startswith("```"):
            if in_code:
                in_code = False
            else:
                lang = line.strip()[3:].strip()
                output.append("【" + ("代码：" + lang if lang else "代码") + "】")
                in_code = True
            i += 1
            continue
        if in_code:
            output.append(line)
            i += 1
            continue
        if i + 2 < len(lines) and "|" in line and "|" in lines[i + 1]:
            headers, rule = _cells(line), _cells(lines[i + 1])
            if len(headers) == len(rule) and len(headers) >= 2 and all(
                re.fullmatch(r":?-{3,}:?", cell) for cell in rule
            ):
                i += 2
                count = 0
                while i < len(lines) and "|" in lines[i]:
                    values = _cells(lines[i])
                    if len(values) != len(headers):
                        break
                    if count:
                        output.append("")
                    output.append("▌" + _inline(values[0], omitted))
                    for key, value in zip(headers[1:], values[1:]):
                        output.append(_inline(key, omitted) + "：" + _inline(value, omitted))
                    i += 1
                    count += 1
                if count:
                    continue
                output.extend([line, " | ".join(rule)])
                continue
        if re.fullmatch(r"\s*(?:-{3,}|\*{3,}|_{3,})\s*", line):
            i += 1
            continue
        line = re.sub(r"^\s{0,3}#{1,6}\s+(.+)$", r"【\1】", line)
        line = re.sub(r"^(\s*)[-*+]\s+", r"\1• ", line)
        line = re.sub(r"^(\s*)(\d+)\.\s+", r"\1\2）", line)
        line = re.sub(r"^\s*>\s?", "│ ", line)
        output.append(_inline(line, omitted))
        i += 1
    result = "\n".join(output).strip()
    result = re.sub(r"\n{3,}", "\n\n", result)
    if omitted[0]:
        result += "\n\n完整路径／来源：回复“原文”查看。"
    return result

"""Configure a Feishu app locally without putting its secret in chat or argv."""
import getpass
import os
import re
import secrets

from bridge_state import private_json
from feishu_bot import directory_path


def main():
    os.umask(0o077)
    directory = directory_path()
    directory.mkdir(parents=True, mode=0o700, exist_ok=True)
    os.chmod(directory, 0o700)
    path = directory / 'config.json'
    if path.exists():
        raise RuntimeError('已有配置，未覆盖。请在本机检查私有配置文件。')
    app_id = input('飞书 App ID：').strip()
    if not re.fullmatch(r'cli_[A-Za-z0-9]+', app_id):
        raise ValueError('App ID 格式应为 cli_ 开头')
    secret = getpass.getpass('飞书 App Secret（输入隐藏）：').strip()
    if not secret:
        raise ValueError('App Secret 不能为空')
    code = secrets.token_hex(6)
    config = {'app_id': app_id, 'app_secret': secret, 'pairing_code': code,
              'initial_thread': os.environ.get('CODEX_THREAD_ID')}
    private_json(path, config)
    print('配置已保存。服务启动后，在飞书私聊机器人发送：/绑定 ' + code)
    print('绑定后仅该用户的私聊消息和按钮操作会进入 Codex。')


if __name__ == '__main__':
    main()

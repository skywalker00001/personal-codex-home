"""Private Feishu app bot: native cards, long connections and Codex tasks."""
from __future__ import annotations

import argparse
import fcntl
import hmac
import json
import os
import re
import signal
import threading
import time
from pathlib import Path

from bridge_state import Catalog, Store, private_json
from feishu_cards import Cards
from feishu_history import HistoryCards
from feishu_settings import SettingsEngine
from session_unlock import summary as unlock_summary, unlock_all
from feishu_media import FeishuMedia, incoming_content


class FeishuEngine(SettingsEngine):
    def _dispatch(self, text):
        command = text.strip().removeprefix('/')
        if command == '解锁全部会话':
            # Hold the engine lock to keep new bridge turns out of this audit.
            with self.lock:
                self.say('正在解锁全部会话；占用的 Codex 连接及当前回复会中断，会话和历史保留。')
                result = unlock_all(self.catalog.home, self.store.directory / 'session-unlock-receipt.json')
            return unlock_summary(result)
        if command == '新建':
            return super()._dispatch('新建 待首条消息')
        return super()._dispatch(text)

    def busy_label(self, ident):
        return super().busy_label(ident).replace('微信', '飞书')

    def title(self, row):
        raw = (self.store.get('aliases', {}).get(row['id']) or row.get('name') or row.get('title')
               or row.get('preview') or row['id'][:8])
        raw = raw.replace(' · 微信分支', '').replace(' · 飞书分支', '')
        if raw.strip() in {'飞书新会话', '微信新会话', '新对话', 'New thread', 'Thread'}:
            raw = row.get('preview') or row.get('id', '')[:8]
        return raw

    def label(self, row):
        title = re.sub(r'\s+', ' ', self.title(row)).strip()
        return title if len(title) <= 42 else title[:41].rstrip() + '…'

    def name_thread(self, rpc, row, thread, text):
        name = re.sub(r'\s+', ' ', text).strip()[:64].rstrip()
        if not name:
            return
        try:
            rpc.call('thread/name/set', {'threadId': thread['id'], 'name': name}, timeout=3)
        except Exception:
            pass
        aliases = self.store.get('aliases', {})
        aliases[thread['id']] = name
        self.store.put('aliases', aliases)
        return name

    def current(self):
        row = self.selected()
        draft = row['id'].startswith('draft:')
        state = '新会话，等待首条消息' if draft else self.busy_label(row['id'])
        if state == '桌面/其他进程占用':
            tip = '可发“历史”查看最近对话；要继续请发“分支”。'
        elif state == '等待你回复':
            tip = '请按上一条请求的编号回复；可发“进度”查看当前状态。'
        elif draft:
            tip = '第一条消息会成为会话主题；新会话默认使用 Full access。'
        else:
            tip = '直接发消息即可继续；发“历史”查看最近对话。'
        effective = self.store.get('feishu_effective_settings', {}).get(row['id'], {})
        model = effective.get('model')
        effort = effective.get('effort')
        last_run = f'\n最近运行模型：{model} / {effort or "默认"}' if model else ''
        return f'当前：{self.label(row)}\n目录：{row.get("cwd") or self.catalog.project}\n状态：{state}\n{tip}{last_run}'

class Bridge:
    def __init__(self, directory, config, catalog, media_handler=None):
        self.directory, self.config = directory, config
        self.media_handler = media_handler
        self.store = Store(directory)
        self.store.put('mobile_mode', False)
        self.engine = FeishuEngine(self.store, catalog, config.get('owner_open_id', ''),
                                  binary=os.environ.get('CODEX_BRIDGE_BIN', 'codex'))
        self.cards = Cards(self.engine)
        self.history = HistoryCards(self.engine, self.cards)
        self.lock = threading.RLock()
        self.stop = threading.Event()
        if not self.store.get('selected') and config.get('initial_thread'):
            catalog.get(config['initial_thread'])
            self.engine.choose(config['initial_thread'])
        if config.get('owner_open_id'):
            self.store.recover(config['owner_open_id'])

    def receive(self, owner, chat, ident, command, *, p2p=True, binding=False, stop_task=None, media=None):
        if not p2p or not owner or not chat or not ident or len(command) > 32000:
            return False
        with self.lock:
            if not self.config.get('owner_open_id'):
                code = self.config.get('pairing_code')
                if not binding or not code or not hmac.compare_digest(command.encode(), ('/绑定 ' + code).encode()):
                    return False
                self.config['owner_open_id'] = owner
                self.config.pop('pairing_code', None)
                private_json(self.directory / 'config.json', self.config)
                self.engine.peer = owner
                self.store.recover(owner)
                command = '菜单'
            if owner != self.config['owner_open_id']:
                return False
            existing = self.store.get('chat:' + owner)
            if not binding and existing != chat:
                return False
            self.store.put('chat:' + owner, chat)
            message = {'message_id': ident, 'from_user_id': owner, 'message_type': 1, 'command': command}
            if media:
                message['feishu_media'] = media
            if stop_task is not None:
                message['stop_task'] = stop_task
            self.store.ingest([message], '', owner)
        return True

    def on_message(self, data):
        event = data.get('event', {})
        message = event.get('message', {})
        kind = message.get('message_type')
        if kind not in {'text', 'image', 'audio', 'post'} or event.get('sender', {}).get('sender_type') != 'user':
            return False
        try:
            text, media = incoming_content(kind, json.loads(message.get('content', '{}')))
        except (ValueError, TypeError):
            return False
        if not isinstance(text, str):
            return False
        created = message.get('create_time')
        if created:
            try:
                if abs(time.time() - int(created) / 1000) > 600:
                    return False
            except (TypeError, ValueError):
                return False
        return self.receive(event.get('sender', {}).get('sender_id', {}).get('open_id'),
                            message.get('chat_id'), message.get('message_id'), text,
                            p2p=message.get('chat_type') == 'p2p', binding=kind == 'text', media=media)

    def on_card(self, data):
        event = data.get('event', {})
        owner = event.get('operator', {}).get('open_id')
        context = event.get('context', {})
        if owner != self.config.get('owner_open_id') or not owner:
            return {'toast': {'type': 'error', 'content': '当前用户未绑定此机器人'}}
        try:
            with self.engine.lock:
                command = self.cards.command(event.get('action', {}).get('value'))
                stop_task = None
                if command == '停止':
                    ident = self.store.get('selected')
                    job = self.engine.jobs.get(ident)
                    stop_task = {'thread': ident, 'started': job['started'] if job and not job['done'].is_set() else None}
                accepted = self.receive(owner, context.get('open_chat_id'), data.get('header', {}).get('event_id'), command,
                                        stop_task=stop_task)
            if not accepted:
                raise ValueError('按钮不属于已绑定的私聊')
            return {'toast': {'type': 'success', 'content': '已接收，结果将在聊天中显示'}}
        except ValueError as exc:
            return {'toast': {'type': 'error', 'content': str(exc)}}

    def process_one(self):
        row = self.store.claim()
        if not row:
            return False
        try:
            body = json.loads(row['body'])
            command = body['command']
            if body.get('feishu_media'):
                if self.media_handler is None:
                    raise RuntimeError('飞书附件处理尚未就绪，请稍后重发')
                if any(item['kind'] == 'audio' for item in body['feishu_media']):
                    self.engine.say('收到语音，正在理解原音。')
                with self.engine.lock:
                    protected = [p for job in self.engine.jobs.values() if not job['done'].is_set() for p in job.get('images', [])]
                command, images, source = self.media_handler.prepare(body['message_id'], command, body['feishu_media'], protected)
                if source == 'feishu-direct-audio':
                    self.store.put('last_voice', dict(source=source, time=time.time()))
                if images:
                    response = self.engine.submit(command, images=images)
                else:
                    response = self.engine.dispatch(command)
                if response:
                    self.engine.say(response)
                return True
            history_command = command[1:] if command.startswith('/') else command
            if history_command == '历史' or history_command.startswith(('飞书历史页 ', '飞书历史全文 ')):
                card = self.history.dispatch(history_command)
                self.store.enqueue_card(self.engine.peer, '对话历史', card)
                response = None
            elif command == '停止' and body.get('stop_task'):
                task = body['stop_task']
                if task['thread'] != self.store.get('selected'):
                    response = '当前会话已切换，请在当前会话的卡片上点击“停止”。'
                elif task['started'] is None:
                    response = '点击时没有正在执行的任务。'
                else:
                    response = self.engine.stop_job(task['thread'], expected_started=task['started'])
            elif command in {'菜单', '帮助', 'help', 'start'}:
                response = '点击卡片按钮管理会话，直接发文字、语音或图片提交任务。图文消息也支持。\n桌面占用的会话可查看历史，或点击“分支”继续。'
            else:
                response = self.engine.dispatch(command)
            if response:
                self.engine.say(response)
        except Exception as exc:
            detail = str(exc)[:1200] if isinstance(exc, (ValueError, RuntimeError)) else type(exc).__name__
            self.engine.say('处理未完成：' + detail)
        finally:
            self.store.finish(row['id'])
        return True

    def send_one(self, send):
        row = self.store.next_outgoing()
        if not row:
            return False
        try:
            chat = self.store.get('chat:' + row['peer'])
            if row['peer'] != self.config.get('owner_open_id') or not chat:
                raise ValueError('收件人未绑定')
            key = 'outgoing_card:' + str(row['id'])
            card = self.store.get(key)
            if card is None:
                card = self.cards.render(row['text'])
                self.store.put(key, card)
            send(chat, card, row['client_id'])
            self.store.sent(row['id'])
        except Exception as exc:
            self.store.failed(row['id'], row['attempts'] + 1, type(exc).__name__)
        return True


def directory_path():
    return Path(os.environ.get('CODEX_FEISHU_STATE', '/aigc/avatar/houyi/.codex-feishu-bridge-state')).resolve()


def serve(directory):
    import lark_oapi as lark
    from lark_oapi.api.im.v1 import CreateMessageRequest, CreateMessageRequestBody
    from lark_oapi.event.callback.model.p2_card_action_trigger import P2CardActionTriggerResponse

    config = json.loads((directory / 'config.json').read_text())
    if not config.get('app_id') or not config.get('app_secret'):
        raise ValueError('请先运行 configure_feishu.py')
    home = Path(os.environ['CODEX_HOME'])
    project = Path(os.environ.get('CODEX_BRIDGE_PROJECT', '/aigc/avatar/houyi'))
    lock_file = (directory / 'service.lock').open('a+')
    fcntl.flock(lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
    client = lark.Client.builder().app_id(config['app_id']).app_secret(config['app_secret']).timeout(30).log_level(lark.LogLevel.ERROR).build()
    bridge = Bridge(directory, config, Catalog(home, project), media_handler=FeishuMedia(client, directory))
    health = {'pid': os.getpid(), 'started': time.time(), 'status': 'connecting',
              'input_types': ['text', 'audio', 'image', 'post'], 'media_handler': 'original-audio-and-native-images'}

    def message(data):
        bridge.on_message(json.loads(lark.JSON.marshal(data)))

    def card(data):
        return P2CardActionTriggerResponse(bridge.on_card(json.loads(lark.JSON.marshal(data))))

    handler = lark.EventDispatcherHandler.builder('', '').register_p2_im_message_receive_v1(message).register_p2_card_action_trigger(card).build()
    websocket = lark.ws.Client(config['app_id'], config['app_secret'], event_handler=handler, log_level=lark.LogLevel.ERROR)

    def send(chat, content, ident):
        body = CreateMessageRequestBody.builder().receive_id(chat).msg_type('interactive').content(json.dumps(content, ensure_ascii=False)).uuid(ident).build()
        request = CreateMessageRequest.builder().receive_id_type('chat_id').request_body(body).build()
        response = client.im.v1.message.create(request)
        if not response.success():
            raise RuntimeError('飞书发送失败，错误码：' + str(response.code))

    def commands():
        while not bridge.stop.is_set():
            if not bridge.process_one():
                bridge.stop.wait(0.25)

    def outbound():
        while not bridge.stop.is_set():
            if not bridge.send_one(send):
                bridge.stop.wait(0.5)
            health.update(status='connected' if getattr(websocket, '_conn', None) is not None else 'connecting',
                          bound=bool(bridge.config.get('owner_open_id')), updated=time.time())
            private_json(directory / 'health.json', health)

    def stop(signum, frame):
        raise KeyboardInterrupt

    for signum in (signal.SIGINT, signal.SIGTERM):
        signal.signal(signum, stop)
    workers = [threading.Thread(target=commands, daemon=True), threading.Thread(target=outbound, daemon=True)]
    private_json(directory / 'health.json', health)
    for worker in workers:
        worker.start()
    try:
        websocket.start()
    finally:
        bridge.stop.set()
        bridge.engine.close()
        for worker in workers:
            worker.join(timeout=3)
        health.update(status='stopped', updated=time.time())
        private_json(directory / 'health.json', health)
        lock_file.close()


def main():
    os.umask(0o077)
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['serve', 'status'])
    args = parser.parse_args()
    directory = directory_path()
    if args.command == 'serve':
        serve(directory)
    else:
        path = directory / 'health.json'
        health = json.loads(path.read_text()) if path.exists() else {'status': 'not_started'}
        config_path = directory / 'config.json'
        config = json.loads(config_path.read_text()) if config_path.exists() else {}
        try:
            running = b'feishu_bot.py\x00serve' in Path(f"/proc/{int(health.get('pid'))}/cmdline").read_bytes()
        except (OSError, TypeError, ValueError):
            running = False
        print(json.dumps({'configured': bool(config.get('app_id') and config.get('app_secret')),
                          'bound': bool(config.get('owner_open_id')), 'running': running, 'health': health}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()

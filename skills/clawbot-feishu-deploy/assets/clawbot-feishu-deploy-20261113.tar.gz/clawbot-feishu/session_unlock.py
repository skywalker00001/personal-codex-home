"""Release this Codex Home's verified app-server writer locks, with a receipt."""
from __future__ import annotations

import argparse
import ctypes
import fcntl
import json
import os
import re
import signal
import stat
import time
from pathlib import Path

from bridge_state import private_json


SESSION_LOCK = re.compile(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\.lock')
_LIBC = ctypes.CDLL(None, use_errno=True)


def open_pidfd(pid):
    # Python 3.10 may omit these wrappers even when libc and the kernel support pidfds.
    if hasattr(os, 'pidfd_open'):
        return os.pidfd_open(pid)
    fd = _LIBC.pidfd_open(ctypes.c_int(pid), ctypes.c_uint(0))
    if fd < 0:
        code = ctypes.get_errno()
        raise OSError(code, os.strerror(code))
    return fd


def send_term(pidfd):
    if hasattr(signal, 'pidfd_send_signal'):
        signal.pidfd_send_signal(pidfd, signal.SIGTERM)
        return
    result = _LIBC.pidfd_send_signal(ctypes.c_int(pidfd), ctypes.c_int(signal.SIGTERM), None,
                                     ctypes.c_uint(0))
    if result < 0:
        code = ctypes.get_errno()
        raise OSError(code, os.strerror(code))


def kernel_locks():
    result = {}
    for line in Path('/proc/locks').read_text().splitlines():
        parts = line.split()
        if len(parts) < 8 or parts[1:4] != ['FLOCK', 'ADVISORY', 'WRITE']:
            continue
        major, minor, inode = parts[5].split(':')
        key = (os.makedev(int(major, 16), int(minor, 16)), int(inode))
        result.setdefault(key, []).append(int(parts[4]))
    return result


def inventory(home):
    home = Path(home).resolve()
    directory = home / 'thread-writer-locks'
    if directory.is_symlink():
        raise ValueError('会话锁目录不能是符号链接。')
    rows = []
    for path in sorted(directory.glob('*.lock')):
        if not SESSION_LOCK.fullmatch(path.name):
            continue
        try:
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        except FileNotFoundError:
            # Codex may remove its lock file between glob() and open() on exit.
            continue
        try:
            info = os.fstat(fd)
            if not stat.S_ISREG(info.st_mode):
                raise ValueError('会话锁必须是普通文件。')
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                locked = True
            else:
                fcntl.flock(fd, fcntl.LOCK_UN)
                locked = False
            rows.append({'path': str(path), 'dev': info.st_dev, 'inode': info.st_ino,
                         'locked': locked,
                         'holders': kernel_locks().get((info.st_dev, info.st_ino), []) if locked else []})
        finally:
            os.close(fd)
    return rows


def process_identity(pid, home):
    home = Path(home).resolve()
    process = Path('/proc') / str(pid)
    fields = (process / 'stat').read_text().rsplit(')', 1)[1].split()
    argv = [arg.decode() for arg in (process / 'cmdline').read_bytes().split(b'\0') if arg]
    executable = os.readlink(process / 'exe')
    environment = (process / 'environ').read_bytes().split(b'\0')
    process_home = next((item.split(b'=', 1)[1].decode() for item in environment
                         if item.startswith(b'CODEX_HOME=')), None)
    if (Path(executable).name not in {'codex', 'codex-linux-x64'} or 'app-server' not in argv
            or not process_home or Path(process_home).resolve() != home):
        raise ValueError(f'进程 {pid} 不是这个 CODEX_HOME 的 Codex app-server，未发送信号。')
    locks = []
    for fd in (process / 'fd').iterdir():
        try:
            target = Path(os.readlink(fd))
            if target.parent.name != 'thread-writer-locks' or not SESSION_LOCK.fullmatch(target.name):
                continue
            fdinfo = (process / 'fdinfo' / fd.name).read_text()
            if not re.search(r'lock:\s+\d+: FLOCK\s+ADVISORY\s+WRITE\s+' + str(pid) + r'\s', fdinfo):
                continue
            if target.parent != home / 'thread-writer-locks':
                raise ValueError(f'进程 {pid} 还持有其他 CODEX_HOME 的锁，未发送信号。')
            info = fd.stat()
            locks.append({'path': str(target), 'fd': fd.name, 'dev': info.st_dev, 'inode': info.st_ino})
        except FileNotFoundError:
            continue
    return {'pid': pid, 'start': fields[19], 'exe': executable, 'argv': argv,
            'home': str(home), 'locks': sorted(locks, key=lambda item: item['path'])}


def verified_holders(home, rows):
    identities = {}
    for row in rows:
        if not row['locked']:
            continue
        if not row['holders']:
            raise ValueError('发现占用锁但无法核实持有进程，未发送信号。')
        for pid in row['holders']:
            identity = identities.setdefault(pid, process_identity(pid, home))
            if not any(all(lock[key] == row[key] for key in ('path', 'dev', 'inode'))
                       for lock in identity['locks']):
                raise ValueError(f'进程 {pid} 的锁 FD 已变化，未发送信号，请重试。')
    return identities


def signal_holder(identity, home):
    # pidfd pins the process even if a PID is reused between inspection and TERM.
    fd = open_pidfd(identity['pid'])
    try:
        current = process_identity(identity['pid'], home)
        if current != identity or not current['locks']:
            raise ValueError(f"进程 {identity['pid']} 的身份或锁已变化，未发送信号，请重试。")
        send_term(fd)
    finally:
        os.close(fd)


def process_exited(identity):
    try:
        fields = (Path('/proc') / str(identity['pid']) / 'stat').read_text().rsplit(')', 1)[1].split()
        return fields[19] != identity['start'] or fields[0] in {'Z', 'X'}
    except FileNotFoundError:
        return True


def unlock_all(home, receipt, *, skip_pids=(), timeout=10):
    receipt = Path(receipt)
    receipt.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    with (receipt.parent / 'session-unlock-operation.lock').open('a+') as guard:
        try:
            fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return {'status': 'busy', 'all_locks_released': False, 'errors': ['已有解锁操作在执行，请稍后重试。']}
        result = {'home': str(Path(home).resolve()), 'started': time.time(), 'status': 'running',
                  'all_locks_released': False, 'signalled': [], 'errors': [], 'receipt': str(receipt)}
        private_json(receipt, result)
        try:
            result['before'] = inventory(home)
            holders = verified_holders(home, result['before'])
            for pid, identity in holders.items():
                if pid in skip_pids:
                    continue
                try:
                    signal_holder(identity, home)
                    result['signalled'].append(identity)
                except (OSError, ValueError) as exc:
                    result['errors'].append(str(exc))
            deadline = time.monotonic() + timeout
            while True:
                result['after'] = inventory(home)
                result['exited'] = {str(item['pid']): process_exited(item) for item in result['signalled']}
                if (not any(row['locked'] for row in result['after']) and all(result['exited'].values())):
                    result['all_locks_released'] = True
                    break
                # Deliberately retained holders are reported, without waiting for them.
                remaining = {pid for row in result['after'] if row['locked'] for pid in row['holders']}
                if remaining.issubset(set(skip_pids)) and all(result['exited'].values()):
                    break
                if time.monotonic() >= deadline:
                    break
                time.sleep(0.1)
            result['status'] = 'complete' if result['all_locks_released'] else 'partial'
        except (OSError, ValueError) as exc:
            result['errors'].append(str(exc))
            result['status'] = 'failed'
        finally:
            result['finished'] = time.time()
            private_json(receipt, result)
        return result


def summary(result):
    if result['status'] == 'busy':
        return result['errors'][0]
    before = sum(row['locked'] for row in result.get('before', []))
    remaining = sum(row['locked'] for row in result.get('after', []))
    if result['all_locks_released']:
        text = f'已解开全部 Codex 会话锁：{before} 个占用锁 → 0 个，已回查确认。'
    else:
        text = f'解锁尚未全部完成，回查仍有 {remaining} 个占用锁。' if 'after' in result else '解锁未完成，无法核实锁状态。'
    if result['errors']:
        text += '\n' + '\n'.join(result['errors'])
    return text + '\n会话和历史已保留。重新打开会话会再次获得锁。'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--home', type=Path, required=True)
    parser.add_argument('--receipt', type=Path)
    parser.add_argument('--skip-pid', type=int, action='append', default=[])
    args = parser.parse_args()
    if args.receipt:
        result = unlock_all(args.home, args.receipt, skip_pids=args.skip_pid)
        print(json.dumps(result, ensure_ascii=False))
    else:
        rows = inventory(args.home)
        print(json.dumps({'locks': rows, 'holders': verified_holders(args.home, rows)}, ensure_ascii=False))


if __name__ == '__main__':
    main()

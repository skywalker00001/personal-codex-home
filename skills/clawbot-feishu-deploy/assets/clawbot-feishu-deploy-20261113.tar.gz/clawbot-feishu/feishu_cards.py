"""Native Feishu schema-2 cards with persisted, scoped callback actions."""
from __future__ import annotations

import secrets
import time

from feishu_settings import PERMISSIONS


class Cards:
    def __init__(self, engine):
        self.engine = engine
        self.store = engine.store

    def button(self, label, command, *, target=None, confirm=False, style='default'):
        token = secrets.token_hex(16)
        actions = self.store.get('feishu_actions', {})
        actions = {key: action for key, action in actions.items() if action['expires'] > time.time()}
        actions[token] = {'command': command, 'target': target, 'expires': time.time() + 86400}
        if command.startswith('飞书选强度 '):
            actions[token]['model'] = self.store.get('feishu_effort_menu', {}).get('model')
        self.store.put('feishu_actions', dict(list(actions.items())[-500:]))
        button = {'tag': 'button', 'text': {'tag': 'plain_text', 'content': label}, 'type': style,
                  'width': 'fill', 'size': 'medium',
                  'behaviors': [{'type': 'callback', 'value': {'token': token}}]}
        if confirm:
            button['confirm'] = {'title': {'tag': 'plain_text', 'content': '确认操作'},
                                 'text': {'tag': 'plain_text', 'content': confirm if isinstance(confirm, str) else '确认对卡片对应的当前会话执行此操作？'}}
        return button

    def row(self, buttons):
        return {'tag': 'column_set', 'flex_mode': 'none', 'horizontal_spacing': '8px', 'columns': [
            {'tag': 'column', 'width': 'weighted', 'weight': 1, 'elements': [button]} for button in buttons]}

    def render(self, text, *, content_elements=None, title=None):
        selected = self.store.get('selected')
        elements = list(content_elements) if content_elements is not None else [{'tag': 'markdown', 'content': text or '请选择操作。'}]
        if text.startswith('选择模型 · 当前会话'):
            menu = self.store.get('feishu_model_menu', {})
            if menu.get('thread') == selected:
                current_model = self.engine.preferences(selected).get('model') or self.engine.selected().get('model')
                buttons = [self.button(model.get('displayName') or model['model'],
                                       '飞书选模型 ' + model['model'], target=selected,
                                       style='primary' if model['model'] == current_model else 'default')
                           for model in menu.get('models', [])]
                for offset in range(0, len(buttons), 2):
                    elements.append(self.row(buttons[offset:offset + 2]))
        if text.startswith('选择权限 · 当前会话'):
            menu = self.store.get('feishu_permission_menu', {})
            if menu.get('thread') == selected:
                for mode in menu.get('modes', []):
                    confirm = '取消当前飞书会话的 Codex 文件和网络沙箱，且不再申请执行审批。确认启用完全访问？' if mode == 'danger-full-access' else False
                    elements.append(self.row([self.button(PERMISSIONS[mode]['label'], '飞书选权限 ' + mode,
                                                         target=selected, confirm=confirm,
                                                         style='primary' if mode == self.engine.preferences(selected).get('permission') else 'default')]))
        if text.startswith('选择推理强度 · 当前会话'):
            menu = self.store.get('feishu_effort_menu', {})
            if menu.get('thread') == selected:
                buttons = [self.button(effort, '飞书选强度 ' + effort, target=selected,
                                       style='primary' if effort == menu.get('current') else 'default')
                           for effort in menu.get('efforts', [])]
                for offset in range(0, len(buttons), 3):
                    elements.append(self.row(buttons[offset:offset + 3]))
        if text.startswith(('最近会话', '收藏会话', '归档会话')):
            for ident in self.store.get('menu', {}).get('ids', []):
                row = self.engine.catalog.get(ident)
                elements.append(self.row([self.button('进入 · ' + self.engine.label(row)[:36], '切换 ' + ident)]))
            elements.append(self.row([self.button('上一页', '上一页'), self.button('下一页', '下一页')]))
        with self.engine.lock:
            pending = list(self.engine.pending.items())
        for token, (job, message) in pending:
            if message['method'] in {'item/commandExecution/requestApproval', 'item/fileChange/requestApproval',
                                     'item/permissions/requestApproval'}:
                elements.append(self.row([self.button('批准 · ' + token, '批准 ' + token, style='primary'),
                                          self.button('拒绝 · ' + token, '拒绝 ' + token, style='danger')]))
        elements.extend([
            {'tag': 'hr'},
            {'tag': 'markdown', 'content': '**会话操作**'},
            self.row([self.button('会话', '会话', style='primary'), self.button('当前', '当前'),
                      self.button('历史', '历史')]),
            self.row([self.button('新建', '新建'),
                      self.button('分支', '分支', target=selected, confirm=True),
                      self.button('停止', '停止', target=selected, style='danger')]),
            self.row([self.button('一键解锁全部会话', '解锁全部会话', style='danger')]),
            {'tag': 'markdown', 'content': '解锁会断开 Houyi 范围内已占用的 Codex 会话并中断当前回复；会话与历史保留。'},
            {'tag': 'markdown', 'content': '**会话设置**'},
            self.row([self.button('选择模型', '飞书模型列表', target=selected),
                      self.button('推理强度', '飞书强度列表', target=selected),
                      self.button('权限', '飞书权限列表', target=selected)]),
        ])
        return {'schema': '2.0',
                'header': {'template': 'indigo' if title else 'blue',
                           'title': {'tag': 'plain_text', 'content': title or 'Houyi Codex · 飞书'}},
                'body': {'padding': '16px', 'vertical_spacing': '8px', 'elements': elements}}

    def command(self, value):
        if not isinstance(value, dict) or not isinstance(value.get('token'), str):
            raise ValueError('无效按钮')
        action = self.store.get('feishu_actions', {}).get(value['token'])
        if not action or action['expires'] <= time.time():
            raise ValueError('卡片已过期，请发送“菜单”刷新')
        if action['command'].startswith(('飞书选模型 ', '飞书选强度 ', '飞书选权限 ', '飞书模型列表', '飞书强度列表', '飞书权限列表')):
            if not action['target'] or action['target'] != self.store.get('selected'):
                raise ValueError('当前会话已切换，请刷新设置卡片后操作')
        if action['command'] in {'停止', '分支'} and (not action['target'] or action['target'] != self.store.get('selected')):
            raise ValueError('当前会话已切换，请刷新卡片后操作')
        if action['command'].startswith(('飞书历史页 ', '飞书历史全文 ')) and action['target'] != self.store.get('selected'):
            raise ValueError('当前会话已切换，请重新点击“历史”')
        if action['command'].startswith('飞书选强度 '):
            menu = self.store.get('feishu_effort_menu', {})
            model = self.engine.preferences(action['target']).get('model') or menu.get('model')
            if action.get('model') != model or action.get('model') != menu.get('model'):
                raise ValueError('模型已变化，请重新打开推理强度菜单')
        return action['command']

"""Readable, role-separated history cards backed by immutable conversation snapshots."""
from __future__ import annotations

import re
import secrets
import time

from bridge_state import split_text
from chat_engine import clean_answer


def readable_text(text):
    """Remove exported line-break artifacts outside code; retain links and code verbatim."""
    lines, fence = [], None
    for line in text.splitlines():
        marker = re.match(r'^\s*(`{3,}|~{3,})', line)
        if marker:
            token = marker.group(1)
            if fence is None:
                fence = token
            elif token[0] == fence[0] and len(token) >= len(fence):
                fence = None
            lines.append(line)
            continue
        if fence is None:
            line = re.sub(r'\\\s*$', '', line)
            line = re.sub(r'&#(?:x20|32);|&nbsp;', ' ', line, flags=re.I)
            line = re.sub(r'^(\s*)[*+]\s+', r'\1- ', line)
        lines.append(line)
    return '\n'.join(lines).strip()


def plain(text, *, size='normal', color='default'):
    return {'tag': 'div', 'text': {'tag': 'plain_text', 'content': text,
                                 'text_size': size, 'text_color': color}}


class HistoryCards:
    PAGE_SIZE = 3
    PREVIEW_SIZE = 700

    def __init__(self, engine, cards):
        self.engine, self.cards, self.store = engine, cards, engine.store

    def open(self):
        row = self.engine.selected()
        entries = [] if row['id'].startswith('draft:') else self.engine.catalog.history(row['id'], limit=None)
        rounds = []
        for role, text in entries:
            if role not in {'user', 'assistant'}:
                continue
            text = readable_text(clean_answer(text) if role == 'assistant' else text)
            if not text:
                continue
            if role == 'user' or not rounds:
                rounds.append([])
            rounds[-1].append({'role': role, 'text': text})
        key = secrets.token_hex(12)
        snapshots = self.store.get('feishu_history_snapshots', {})
        snapshots = {key: value for key, value in snapshots.items() if value['expires'] > time.time()}
        snapshots[key] = {'thread': row['id'], 'title': self.engine.label(row),
                          'rounds': rounds, 'expires': time.time() + 86400}
        self.store.put('feishu_history_snapshots', dict(list(snapshots.items())[-8:]))
        return self.page(key, 0)

    def snapshot(self, key):
        snapshot = self.store.get('feishu_history_snapshots', {}).get(key)
        if not snapshot or snapshot['expires'] <= time.time():
            raise ValueError('这份历史已过期，请重新点击“历史”。')
        if snapshot['thread'] != self.store.get('selected'):
            raise ValueError('当前会话已切换，请重新点击“历史”。')
        return snapshot

    def message(self, entry, *, extra=None, full=False, label=None):
        user = entry['role'] == 'user'
        text = entry['text']
        short = full or len(text) <= self.PREVIEW_SIZE
        elements = [plain(label or ('👤 你 · 消息' if user else '🤖 Codex · 回复'),
                          size='heading-4', color='blue' if user else 'grey')]
        if user or not short:
            elements.append(plain(text if short else text[:self.PREVIEW_SIZE] + '…'))
        else:
            elements.append({'tag': 'markdown', 'content': text})
        if not short:
            elements.append(plain('内容较长，以上为预览。', size='notation', color='grey'))
        if extra:
            elements.append(extra)
        return {'tag': 'column_set', 'flex_mode': 'none', 'columns': [{
            'tag': 'column', 'width': 'weighted', 'weight': 1,
            'background_style': 'blue-50' if user else 'grey-50',
            'padding': '12px', 'vertical_spacing': '8px', 'elements': elements}]}

    def page(self, key, page):
        snapshot = self.snapshot(key)
        rounds = snapshot['rounds']
        pages = max(1, (len(rounds) + self.PAGE_SIZE - 1) // self.PAGE_SIZE)
        if not 0 <= page < pages:
            raise ValueError('没有这一页历史，请重新点击“历史”。')
        end = len(rounds) - page * self.PAGE_SIZE
        start = max(0, end - self.PAGE_SIZE)
        elements = [plain(('最近对话' if page == 0 else '更早对话') + f' · 第 {page + 1}/{pages} 页', size='heading-4'),
                    plain('每轮由上到下阅读：浅蓝是你，浅灰是 Codex。', size='notation', color='grey')]
        if not rounds:
            elements.append(plain('这个会话还没有可显示的对话。'))
        for index in range(start, end):
            if index > start:
                elements.append({'tag': 'hr'})
            elements.append(plain('对话 ' + str(index + 1), size='notation', color='grey'))
            for position, entry in enumerate(rounds[index]):
                extra = None
                if len(entry['text']) > self.PREVIEW_SIZE:
                    extra = self.cards.button('查看完整消息' if entry['role'] == 'user' else '查看完整回复',
                                              f'飞书历史全文 {key} {index} {position} 0', target=snapshot['thread'])
                elements.append(self.message(entry, extra=extra))
            if not any(entry['role'] == 'assistant' for entry in rounds[index]):
                elements.append(self.message({'role': 'assistant', 'text': '这轮还没有已保存的回复。'},
                                             label='🤖 Codex · 暂无回复'))
        buttons = []
        if page + 1 < pages:
            buttons.append(self.cards.button('← 更早对话', f'飞书历史页 {key} {page + 1}', target=snapshot['thread']))
        if page > 0:
            buttons.append(self.cards.button('较新对话 →', f'飞书历史页 {key} {page - 1}', target=snapshot['thread']))
        if buttons:
            elements.append(self.cards.row(buttons))
        elements.append(plain('点击下方“历史”刷新最近对话。', size='notation', color='grey'))
        return self.cards.render('', content_elements=elements, title='对话历史 · ' + snapshot['title'])

    def detail(self, key, index, position, part):
        snapshot = self.snapshot(key)
        if not 0 <= index < len(snapshot['rounds']) or not 0 <= position < len(snapshot['rounds'][index]):
            raise ValueError('没有这条历史消息，请重新点击“历史”。')
        entry = snapshot['rounds'][index][position]
        chunks = split_text(entry['text'], limit=7000)
        if not 0 <= part < len(chunks):
            raise ValueError('没有这一段原文。')
        # Plain text preserves every character, including code/links split across pages.
        elements = [plain(f'对话 {index + 1} · 全文 {part + 1}/{len(chunks)}', size='heading-4'),
                    self.message({'role': entry['role'], 'text': chunks[part]}, full=True)]
        if entry['role'] == 'assistant' and len(chunks) > 1:
            elements[1]['columns'][0]['elements'][1] = plain(chunks[part])
        buttons = []
        for step, label in [(-1, '← 上一段'), (1, '下一段 →')]:
            if 0 <= part + step < len(chunks):
                buttons.append(self.cards.button(label, f'飞书历史全文 {key} {index} {position} {part + step}',
                                                 target=snapshot['thread']))
        if buttons:
            elements.append(self.cards.row(buttons))
        page = (len(snapshot['rounds']) - index - 1) // self.PAGE_SIZE
        elements.append(self.cards.row([self.cards.button('返回对话历史', f'飞书历史页 {key} {page}', target=snapshot['thread'])]))
        return self.cards.render('', content_elements=elements, title='历史全文 · ' + snapshot['title'])

    def dispatch(self, command):
        if command == '历史':
            return self.open()
        parts = command.split()
        try:
            if len(parts) == 3 and parts[0] == '飞书历史页':
                return self.page(parts[1], int(parts[2]))
            if len(parts) == 5 and parts[0] == '飞书历史全文':
                return self.detail(parts[1], *map(int, parts[2:]))
        except (ValueError, TypeError) as error:
            raise ValueError(str(error)) from error
        raise ValueError('无效历史操作，请重新点击“历史”。')
